#' Build the environment for `strategize`. Creates a conda environment in which
#' JAX and NumPy are installed. Users may also create such an environment
#' themselves.
#'
#' @param conda_env Name of the conda environment in which to place the backends.
#'   Defaults to \code{"strategize_env"}.
#' @param conda The path to a conda executable. Using \code{"auto"} allows reticulate
#'   to attempt to automatically find an appropriate conda binary. Defaults to \code{"auto"}.
#'   If creation fails and a conda binary is found on PATH, the function retries with it.
#'
#' @return Invisibly returns \code{NULL}. This function is called for its side effects
#'   of creating and configuring a conda environment for \code{strategize}.
#'   This function requires an Internet connection.
#'   You can find a list of conda Python paths via: \code{Sys.which("python")}
#'
#' @examples
#' \dontrun{
#' # Create a conda environment named "strategize"
#' # and install the required Python packages (jax, numpy, etc.)
#' build_backend(conda_env = "strategize", conda = "auto")
#'
#' # If you want to specify a particular conda path:
#' # build_backend(conda_env = "strategize", conda = "/usr/local/bin/conda")
#' }
#'
#' @export
#' @md

build_backend <- function(conda_env = "strategize_env", conda = "auto") {
  env_exists <- function(conda_bin) {
    tryCatch({
      envs <- reticulate::conda_list(conda = conda_bin)
      conda_env %in% envs$name
    }, error = function(e) FALSE)
  }

  create_env <- function(conda_bin) {
    reticulate::conda_create(envname = conda_env, conda = conda_bin, python_version = "3.13")
    invisible(TRUE)
  }

  ok <- tryCatch({
    create_env(conda)
    TRUE
  }, error = function(e) {
    message(sprintf("conda_create failed using '%s': %s", conda, e$message))
    FALSE
  })

  if (!ok || !env_exists(conda)) {
    conda_fallback <- Sys.which("conda")
    if (nzchar(conda_fallback) && conda_fallback != conda) {
      message(sprintf("Retrying conda_create with: %s", conda_fallback))
      tryCatch({
        create_env(conda_fallback)
      }, error = function(e) {
        message(sprintf("conda_create failed using '%s': %s", conda_fallback, e$message))
      })
      if (env_exists(conda_fallback)) {
        conda <- conda_fallback
      }
    }
  }

  if (!env_exists(conda)) {
    stop(
      sprintf("Failed to create conda environment '%s'.\n", conda_env),
      "Try passing conda = '/path/to/conda' or setting RETICULATE_CONDA.\n",
      call. = FALSE
    )
  }
  
  os <- Sys.info()[["sysname"]]
  msg <- function(...) message(sprintf(...))
  
  pip_install <- function(pkgs, ...) {
    reticulate::py_install(packages = pkgs, envname = conda_env, conda = conda, pip = TRUE, ...)
    TRUE
  }
  
  # --- (A) Choose CUDA 13 vs 12 *by driver version* and install JAX FIRST ---
  install_jax_gpu <- function() {
    if (!identical(os, "Linux")){
      return(pip_install("jax")) 
    }
    
    # Read driver version as integer major (e.g., 580)
    drv <- try(suppressWarnings(system("nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -n1", intern=TRUE)), TRUE)
    drv_major <- suppressWarnings(as.integer(sub("^([0-9]+).*", "\\1", drv[1])))
    
    # Prefer CUDA 13 if the driver is new enough; otherwise CUDA 12; else CPU fallback
    if (!is.na(drv_major) && drv_major >= 580) {
      msg("Driver %s detected (>=580): installing JAX CUDA 13 wheels.", drv[1])
      tryCatch(pip_install('jax[cuda13]'), error = function(e) {
        msg("CUDA 13 wheels failed (%s); falling back to CUDA 12.", e$message)
        pip_install('jax[cuda12]')
      })
    } else if (!is.na(drv_major) && drv_major >= 525) {
      msg("Driver %s detected (>=525,<580): installing JAX CUDA 12 wheels.", drv[1])
      pip_install('jax[cuda12]')
    } else {
      msg("Driver %s too old for CUDA wheels; installing CPU-only JAX.", drv[1])
      pip_install('jax')
    }
  }
  
  # (Optional) neutralize LD_LIBRARY_PATH inside this env to prevent overrides
  try({
    actdir <- file.path(Sys.getenv("HOME"), "miniconda3/envs", conda_env, "etc", "conda", "activate.d")
    dir.create(actdir, recursive = TRUE, showWarnings = FALSE)
    writeLines("unset LD_LIBRARY_PATH", file.path(actdir, "00-unset-ld.sh"))
  }, silent = TRUE)
  
  # Install JAX first (so later deps don't pull a CPU variant)
  install_jax_gpu()
  
  # --- (B) Now install the rest (pip’s default upgrade strategy is "only-if-needed") ---
  other_pkgs <- c("numpy", "equinox", "numpyro", "optax")
  pip_install(other_pkgs)
  
  msg("Environment '%s' is ready.", conda_env)
}
