neural_get_party_index <- function(model_info, party_label = NULL){
  if (is.null(model_info) || is.null(model_info$party_levels)) {
    return(ai(0L))
  }
  if (!is.null(model_info$party_index_map) && !is.null(party_label)) {
    key <- as.character(party_label)
    if (key %in% names(model_info$party_index_map)) {
      return(ai(model_info$party_index_map[[key]]))
    }
  }
  if (is.null(party_label)) {
    return(ai(0L))
  }
  idx <- match(as.character(party_label), model_info$party_levels) - 1L
  if (is.na(idx)) ai(0L) else ai(idx)
}

neural_get_resp_party_index <- function(model_info, party_label = NULL){
  if (is.null(model_info) || is.null(model_info$resp_party_levels)) {
    return(ai(0L))
  }
  if (!is.null(model_info$resp_party_index_map) && !is.null(party_label)) {
    key <- as.character(party_label)
    if (key %in% names(model_info$resp_party_index_map)) {
      return(ai(model_info$resp_party_index_map[[key]]))
    }
  }
  if (is.null(party_label)) {
    return(ai(0L))
  }
  idx <- match(as.character(party_label), model_info$resp_party_levels) - 1L
  if (is.na(idx)) ai(0L) else ai(idx)
}

neural_stage_index <- function(party_left_idx, party_right_idx, model_info = NULL) {
  mode <- NULL
  if (!is.null(model_info) && !is.null(model_info$stage_mode)) {
    mode <- tolower(as.character(model_info$stage_mode))
  }
  if (length(mode) != 1L || is.na(mode) || !nzchar(mode)) {
    mode <- "same"
  }

  has_shape <- function(x) {
    tryCatch({
      x$shape
      TRUE
    }, error = function(e) FALSE)
  }
  if (has_shape(party_left_idx) || has_shape(party_right_idx)) {
    pl <- strenv$jnp$array(party_left_idx)
    pr <- strenv$jnp$array(party_right_idx)
    same <- strenv$jnp$equal(pl, pr)
    stage <- if (identical(mode, "different")) {
      strenv$jnp$logical_not(same)
    } else {
      same
    }
    return(strenv$jnp$astype(stage, strenv$jnp$int32))
  }

  same <- ai(party_left_idx) == ai(party_right_idx)
  if (identical(mode, "different")) {
    return(ifelse(same, 0L, 1L))
  }
  ifelse(same, 1L, 0L)
}

neural_matchup_index <- function(party_left_idx, party_right_idx, model_info){
  if (is.null(model_info)) {
    return(NULL)
  }
  n_party_levels <- if (!is.null(model_info$n_party_levels)) {
    as.integer(model_info$n_party_levels)
  } else if (!is.null(model_info$party_levels)) {
    length(model_info$party_levels)
  } else {
    NA_integer_
  }
  if (is.na(n_party_levels) || n_party_levels < 1L) {
    return(NULL)
  }
  pl <- strenv$jnp$array(party_left_idx)
  pr <- strenv$jnp$array(party_right_idx)
  p_min <- strenv$jnp$minimum(pl, pr)
  p_max <- strenv$jnp$maximum(pl, pr)
  half_term <- strenv$jnp$floor_divide(p_min * (p_min - 1L), ai(2L))
  idx <- p_min * ai(n_party_levels) - half_term + (p_max - p_min)
  strenv$jnp$astype(idx, strenv$jnp$int32)
}

neural_logits_to_q <- function(logits, likelihood){
  if (likelihood == "bernoulli") {
    prob <- strenv$jax$nn$sigmoid(strenv$jnp$squeeze(logits, axis = 1L))
    return(strenv$jnp$reshape(prob, list(1L, 1L)))
  }
  if (likelihood == "categorical") {
    probs <- strenv$jax$nn$softmax(logits, axis = -1L)
    prob <- strenv$jnp$take(probs, 1L, axis = 1L)
    return(strenv$jnp$reshape(prob, list(1L, 1L)))
  }
  mu <- strenv$jnp$squeeze(logits, axis = 1L)
  strenv$jnp$reshape(mu, list(1L, 1L))
}

neural_params_from_theta <- function(theta_vec, model_info){
  if (is.null(model_info)) {
    stop("neural_params_from_theta requires a non-null model_info.", call. = FALSE)
  }
  if (is.null(theta_vec)) {
    return(model_info$params)
  }
  schema_missing <- is.null(model_info$param_names) ||
    is.null(model_info$param_offsets) ||
    is.null(model_info$param_sizes) ||
    is.null(model_info$param_shapes)
  if (isTRUE(schema_missing)) {
    if (!is.null(model_info$params) &&
        !is.null(model_info$n_factors) &&
        !is.null(model_info$model_depth)) {
      schema <- neural_build_param_schema(
        params = model_info$params,
        n_factors = model_info$n_factors,
        model_depth = model_info$model_depth
      )
      model_info$param_names <- schema$param_names
      model_info$param_shapes <- schema$param_shapes
      model_info$param_sizes <- schema$param_sizes
      model_info$param_offsets <- schema$param_offsets
      if (is.null(model_info$n_params)) {
        model_info$n_params <- schema$n_params
      }
    } else {
      stop("model_info is missing parameter schema; cannot unpack theta_vec.", call. = FALSE)
    }
  }
  theta_vec <- strenv$jnp$reshape(theta_vec, list(-1L))
  offsets_num <- as.integer(unlist(model_info$param_offsets))
  sizes_num <- as.integer(unlist(model_info$param_sizes))
  if (length(offsets_num) != length(sizes_num)) {
    stop("param_offsets and param_sizes length mismatch in model_info.", call. = FALSE)
  }
  theta_len <- as.integer(theta_vec$shape[[1]])
  max_end <- if (length(sizes_num) > 0L) max(offsets_num + sizes_num) else 0L
  expected_total <- if (!is.null(model_info$n_params)) as.integer(model_info$n_params) else max_end
  if (is.finite(theta_len) && is.finite(expected_total) && theta_len != expected_total) {
    stop(sprintf("theta_vec length (%d) does not match expected parameter total (%d).",
                 theta_len, expected_total),
         call. = FALSE)
  }
  if (is.finite(theta_len) && is.finite(max_end) && theta_len < max_end) {
    stop(sprintf("theta_vec length (%d) is shorter than required (%d).",
                 theta_len, max_end),
         call. = FALSE)
  }
  params <- list()
  param_names <- model_info$param_names
  param_offsets <- model_info$param_offsets
  param_sizes <- model_info$param_sizes
  param_shapes <- model_info$param_shapes
  for (i_ in seq_along(param_names)) {
    start <- as.integer(param_offsets[[i_]])
    size <- as.integer(param_sizes[[i_]])
    if (is.finite(theta_len) && is.finite(start) && is.finite(size) &&
        (start < 0L || (start + size) > theta_len)) {
      stop(sprintf("theta_vec slice for '%s' (%d..%d) exceeds length (%d).",
                   param_names[[i_]], start, start + size - 1L, theta_len),
           call. = FALSE)
    }
    idx <- strenv$jnp$arange(ai(start), ai(start + size))
    slice <- strenv$jnp$take(theta_vec, idx, axis = 0L)
    shape_use <- param_shapes[[i_]]
    if (length(shape_use) == 0L) {
      shape_use <- c(1L)
    }
    shape_size <- as.integer(prod(shape_use))
    if (is.finite(size) && is.finite(shape_size) && size != shape_size) {
      stop(sprintf("Param '%s' size (%d) does not match shape product (%d).",
                   param_names[[i_]], size, shape_size),
           call. = FALSE)
    }
    params[[param_names[[i_]]]] <- strenv$jnp$reshape(slice, as.integer(shape_use))
  }
  params
}

neural_build_param_schema <- function(params,
                                      n_factors,
                                      model_depth) {
  if (is.null(params) || !is.list(params)) {
    stop("neural_build_param_schema requires a params list.", call. = FALSE)
  }
  n_factors <- as.integer(n_factors)
  model_depth <- as.integer(model_depth)
  if (is.na(n_factors) || n_factors < 1L) {
    stop("neural_build_param_schema requires n_factors >= 1.", call. = FALSE)
  }
  if (is.na(model_depth) || model_depth < 1L) {
    stop("neural_build_param_schema requires model_depth >= 1.", call. = FALSE)
  }

  param_names <- c(paste0("E_factor_", seq_len(n_factors)),
                   "E_feature_id",
                   "E_party", "E_resp_party", "E_choice",
                   "E_sep", "E_segment")
  if (!is.null(params$E_stage)) {
    param_names <- c(param_names, "E_stage")
  }
  if (!is.null(params$E_matchup)) {
    param_names <- c(param_names, "E_matchup")
  }
  if (!is.null(params$E_rel)) {
    param_names <- c(param_names, "E_rel")
  }
  if (!is.null(params$W_resp_x)) {
    param_names <- c(param_names, "W_resp_x")
  }
  if (!is.null(params$M_cross)) {
    param_names <- c(param_names, "M_cross")
  }
  if (!is.null(params$W_cross_out)) {
    param_names <- c(param_names, "W_cross_out")
  }
  for (l_ in 1L:model_depth) {
    param_names <- c(param_names,
                     paste0("alpha_attn_l", l_),
                     paste0("alpha_ff_l", l_),
                     paste0("RMS_attn_l", l_),
                     paste0("RMS_ff_l", l_),
                     paste0("W_q_l", l_),
                     paste0("W_k_l", l_),
                     paste0("W_v_l", l_),
                     paste0("W_o_l", l_),
                     paste0("W_ff1_l", l_),
                     paste0("W_ff2_l", l_))
  }
  param_names <- c(param_names, "RMS_final", "W_out", "b_out")
  if (!is.null(params$sigma)) {
    param_names <- c(param_names, "sigma")
  }
  param_names <- param_names[param_names %in% names(params)]

  param_shapes <- lapply(param_names, function(name) {
    shape <- tryCatch(reticulate::py_to_r(params[[name]]$shape), error = function(e) NULL)
    if (is.null(shape)) integer(0) else as.integer(shape)
  })
  param_sizes <- vapply(param_shapes, function(shape) {
    if (length(shape) == 0L) {
      1L
    } else {
      as.integer(prod(shape))
    }
  }, integer(1))
  param_offsets <- as.integer(cumsum(c(0L, param_sizes))[seq_len(length(param_sizes))])
  param_total <- sum(param_sizes)

  list(
    param_names = param_names,
    param_shapes = param_shapes,
    param_sizes = param_sizes,
    param_offsets = param_offsets,
    n_params = ai(param_total)
  )
}

neural_flatten_params <- function(params, schema, dtype = NULL) {
  if (is.null(dtype)) {
    dtype <- strenv$jnp$float32
  }
  parts <- lapply(schema$param_names, function(name) {
    strenv$jnp$ravel(params[[name]])
  })
  if (length(parts) == 0L) {
    return(strenv$jnp$array(numeric(0), dtype = dtype))
  }
  strenv$jnp$concatenate(parts, axis = 0L)
}

neural_cross_encoder_mode <- function(model_info) {
  mode <- NULL
  if (!is.null(model_info$cross_candidate_encoder_mode)) {
    mode <- tolower(as.character(model_info$cross_candidate_encoder_mode))
  }
  if (length(mode) != 1L || is.na(mode) || !nzchar(mode)) {
    if (isTRUE(model_info$cross_candidate_encoder)) {
      return("term")
    }
    return("none")
  }
  if (mode %in% c("none", "term", "full")) {
    return(mode)
  }
  if (mode %in% c("true", "false")) {
    return(ifelse(mode == "true", "term", "none"))
  }
  if (isTRUE(model_info$cross_candidate_encoder)) {
    return("term")
  }
  "none"
}

neural_rms_norm <- function(x, g, model_dims, eps = 1e-6) {
  if (is.null(g)) {
    return(x)
  }
  mean_sq <- strenv$jnp$mean(x * x, axis = -1L, keepdims = TRUE)
  inv_rms <- strenv$jnp$reciprocal(strenv$jnp$sqrt(mean_sq + eps))
  g_use <- strenv$jnp$reshape(g, list(1L, 1L, ai(model_dims)))
  x * inv_rms * g_use
}

neural_param_or_default <- function(params, name, default) {
  val <- params[[name]]
  if (is.null(val)) {
    return(default)
  }
  val
}

neural_add_segment_embedding <- function(tokens, segment_idx, model_info, params = NULL){
  if (is.null(params)) {
    params <- model_info$params
  }
  if (is.null(params$E_segment)) {
    return(tokens)
  }
  seg_vec <- strenv$jnp$take(params$E_segment, ai(segment_idx), axis = 0L)
  seg_tok <- strenv$jnp$reshape(seg_vec, list(1L, 1L, ai(model_info$model_dims)))
  tokens + seg_tok
}

neural_build_sep_token <- function(model_info, n_batch = NULL, params = NULL){
  if (is.null(params)) {
    params <- model_info$params
  }
  sep_vec <- if (!is.null(params$E_sep)) {
    params$E_sep
  } else {
    strenv$jnp$zeros(list(ai(model_info$model_dims)), dtype = strenv$dtj)
  }
  sep_tok <- strenv$jnp$reshape(sep_vec, list(1L, 1L, ai(model_info$model_dims)))
  if (is.null(n_batch)) {
    return(sep_tok)
  }
  sep_tok * strenv$jnp$ones(list(ai(n_batch), 1L, 1L))
}

add_party_rel_tokens <- function(tokens,
                                       party_idx,
                                       model_info,
                                       resp_party_idx = NULL,
                                       params = NULL,
                                       use_role = FALSE,
                                       role_id = NULL,
                                       require_party = TRUE){
  if (is.null(params)) {
    params <- model_info$params
  }
  tok_ndim <- length(tokens$shape)

  if (!is.null(params$E_feature_id)) {
    dims <- ai(model_info$model_dims)
    feature_tok <- if (tok_ndim == 3L) {
      strenv$jnp$reshape(params$E_feature_id, list(1L, tokens$shape[[2]], dims))
    } else if (tok_ndim == 2L) {
      strenv$jnp$reshape(params$E_feature_id, list(tokens$shape[[1]], dims))
    } else {
      NULL
    }
    if (!is.null(feature_tok)) {
      tokens <- tokens + feature_tok
    }
  }

  if (isTRUE(require_party) && is.null(params$E_party)) {
    stop("E_party is required for party/rel tokens.")
  }

  party_idx_arr <- strenv$jnp$array(party_idx)
  party_idx_arr <- strenv$jnp$astype(party_idx_arr, strenv$jnp$int32)

  party_vec <- NULL
  if (!is.null(params$E_party)) {
    party_vec <- strenv$jnp$take(params$E_party, party_idx_arr, axis = 0L)
  }

  if (isTRUE(use_role) && !is.null(params$E_role)) {
    role_id_use <- if (is.null(role_id)) 0L else role_id
    n_roles <- ai(params$E_role$shape[[1]])
    role_use <- if (ai(role_id_use) >= n_roles) 0L else ai(role_id_use)
    role_vec <- strenv$jnp$take(params$E_role, strenv$jnp$array(ai(role_use)), axis = 0L)

    dims <- ai(model_info$model_dims)
    role_add <- if (tok_ndim == 3L) {
      strenv$jnp$reshape(role_vec, list(1L, 1L, dims))
    } else {
      strenv$jnp$reshape(role_vec, list(1L, dims))
    }
    tokens <- tokens + role_add

    if (!is.null(party_vec)) {
      party_vec <- party_vec + strenv$jnp$reshape(role_vec, list(dims))
    }
  }

  if (!is.null(party_vec)) {
    dims <- ai(model_info$model_dims)
    party_tok <- if (tok_ndim == 3L) {
      strenv$jnp$reshape(party_vec, list(tokens$shape[[1]], 1L, dims))
    } else {
      strenv$jnp$reshape(party_vec, list(1L, dims))
    }
    tokens <- strenv$jnp$concatenate(list(tokens, party_tok),
                                     axis = if (tok_ndim == 3L) 1L else 0L)
  }

  if (!is.null(params$E_rel)) {
    rel_idx <- if (is.null(model_info$cand_party_to_resp_idx) || is.null(resp_party_idx)) {
      if (tok_ndim == 3L) {
        strenv$jnp$full(list(tokens$shape[[1]]), ai(2L))
      } else {
        ai(2L)
      }
    } else {
      cand_map <- strenv$jnp$atleast_1d(model_info$cand_party_to_resp_idx)
      cand_resp_idx <- strenv$jnp$take(cand_map, party_idx_arr, axis = 0L)
      is_known <- cand_resp_idx >= 0L
      resp_arr <- strenv$jnp$array(resp_party_idx)
      is_match <- strenv$jnp$equal(cand_resp_idx, resp_arr)
      strenv$jnp$where(is_match, ai(0L),
                       strenv$jnp$where(is_known, ai(1L), ai(2L)))
    }
    rel_idx <- strenv$jnp$astype(strenv$jnp$array(rel_idx), strenv$jnp$int32)
    rel_vec <- strenv$jnp$take(params$E_rel, rel_idx, axis = 0L)
    dims <- ai(model_info$model_dims)
    rel_tok <- if (tok_ndim == 3L) {
      strenv$jnp$reshape(rel_vec, list(tokens$shape[[1]], 1L, dims))
    } else {
      strenv$jnp$reshape(rel_vec, list(1L, dims))
    }
    tokens <- strenv$jnp$concatenate(list(tokens, rel_tok),
                                     axis = if (tok_ndim == 3L) 1L else 0L)
  }

  tokens
}

add_context_tokens <- function(model_info,
                                      resp_party_idx,
                                      stage_idx = NULL,
                                      matchup_idx = NULL,
                                      resp_cov = NULL,
                                      params = NULL,
                                      batch = FALSE){
  if (is.null(params)) {
    params <- model_info$params
  }
  token_list <- list()
  dims <- ai(model_info$model_dims)
  is_batch <- isTRUE(batch)

  resp_party_idx_use <- if (is.null(resp_party_idx)) 0L else resp_party_idx
  if (!is_batch) {
    resp_party_idx_use <- ai(resp_party_idx_use)
    resp_party_idx_use <- strenv$jnp$atleast_1d(strenv$jnp$array(resp_party_idx_use))
  } else {
    resp_party_idx_use <- strenv$jnp$atleast_1d(resp_party_idx_use)
  }

  stage_idx_use <- NULL
  if (!is.null(stage_idx)) {
    if (!is_batch) {
      stage_use <- ai(stage_idx)
      if (ai(stage_use) < 0L) stage_use <- 0L
      stage_idx_use <- strenv$jnp$atleast_1d(strenv$jnp$array(stage_use))
    } else {
      stage_idx_use <- strenv$jnp$atleast_1d(stage_idx)
    }
  }

  matchup_idx_use <- NULL
  if (!is.null(matchup_idx)) {
    matchup_idx_use <- strenv$jnp$atleast_1d(matchup_idx)
  }

  N_batch <- 1L
  if (is_batch) {
    N_batch <- tryCatch(ai(resp_party_idx_use$shape[[1L]]), error = function(e) 1L)
  }

  if (!is.null(params$E_stage) && !is.null(stage_idx_use)) {
    stage_vec <- params$E_stage[resp_party_idx_use, stage_idx_use]
    stage_tok <- strenv$jnp$reshape(stage_vec, list(-1L, 1L, dims))
    token_list[[length(token_list) + 1L]] <- stage_tok
  }
  if (!is.null(params$E_resp_party)) {
    resp_vec <- strenv$jnp$take(params$E_resp_party, resp_party_idx_use, axis = 0L)
    resp_tok <- strenv$jnp$reshape(resp_vec, list(-1L, 1L, dims))
    token_list[[length(token_list) + 1L]] <- resp_tok
  }
  if (!is.null(params$E_matchup) && !is.null(matchup_idx_use)) {
    matchup_vec <- strenv$jnp$take(params$E_matchup, matchup_idx_use, axis = 0L)
    matchup_tok <- strenv$jnp$reshape(matchup_vec, list(-1L, 1L, dims))
    token_list[[length(token_list) + 1L]] <- matchup_tok
  }
  if (!is.null(params$W_resp_x)) {
    use_resp_cov <- TRUE
    if (!is_batch) {
      use_resp_cov <- !is.null(model_info$resp_cov_mean) &&
        ai(model_info$n_resp_covariates) > 0L
    }
    if (use_resp_cov) {
      if (is.null(resp_cov) && !is.null(model_info$resp_cov_mean)) {
        resp_cov <- model_info$resp_cov_mean
      }
      if (!is.null(resp_cov)) {
        resp_cov_mat <- strenv$jnp$atleast_2d(resp_cov)
        if (ai(resp_cov_mat$shape[[2]]) > 0L) {
          if (ai(resp_cov_mat$shape[[1]]) == 1L && is_batch && N_batch > 1L) {
            resp_cov_mat <- resp_cov_mat * strenv$jnp$ones(list(N_batch, 1L))
          }
          cov_vec <- strenv$jnp$einsum("nc,cm->nm", resp_cov_mat, params$W_resp_x)
          cov_tok <- strenv$jnp$reshape(cov_vec, list(-1L, 1L, dims))
          token_list[[length(token_list) + 1L]] <- cov_tok
        }
      }
    }
  }

  if (length(token_list) == 0L) {
    return(NULL)
  }
  strenv$jnp$concatenate(token_list, axis = 1L)
}

neural_build_candidate_tokens_hard <- function(X_idx, party_idx, model_info,
                                               resp_party_idx = NULL,
                                               params = NULL){
  if (is.null(params)) {
    params <- model_info$params
  }
  D_local <- ai(X_idx$shape[[2]])
  token_list <- vector("list", D_local)
  for (d_ in 1L:D_local) {
    E_d <- params[[paste0("E_factor_", d_)]]
    idx_d <- strenv$jnp$take(X_idx, ai(d_ - 1L), axis = 1L)
    token_list[[d_]] <- strenv$jnp$take(E_d, idx_d, axis = 0L)
  }
  tokens <- strenv$jnp$stack(token_list, axis = 1L)
  add_party_rel_tokens(tokens,
                       party_idx = party_idx,
                       resp_party_idx = resp_party_idx,
                       model_info = model_info,
                       params = params,
                       require_party = FALSE)
}

neural_build_context_tokens_batch <- function(model_info,
                                              resp_party_idx,
                                              stage_idx = NULL,
                                              matchup_idx = NULL,
                                              resp_cov = NULL,
                                              params = NULL){
  add_context_tokens(model_info = model_info,
                     resp_party_idx = resp_party_idx,
                     stage_idx = stage_idx,
                     matchup_idx = matchup_idx,
                     resp_cov = resp_cov,
                     params = params,
                     batch = TRUE)
}

neural_build_candidate_tokens_soft <- function(pi_vec, party_idx, role_id, model_info, params = NULL,
                                               use_role = FALSE, resp_party_idx = NULL){
  if (is.null(params)) {
    params <- model_info$params
  }
  pi_vec <- strenv$jnp$reshape(pi_vec, list(-1L))
  token_list <- vector("list", ai(model_info$n_factors))
  for (d_ in seq_len(ai(model_info$n_factors))) {
    idx <- model_info$factor_index_list[[d_]]
    idx <- strenv$jnp$atleast_1d(idx)
    p_sub <- strenv$jnp$take(pi_vec, idx, axis = 0L)
    p_full <- apply_implicit_parameterization_jnp(p_sub,
                                                  implicit = isTRUE(model_info$implicit),
                                                  axis = 0L,
                                                  clip = TRUE)
    E_d <- params[[paste0("E_factor_", d_)]]
    n_p <- ai(p_full$shape[[1]])
    n_e <- ai(E_d$shape[[1]])
    if (!is.na(n_p) && !is.na(n_e) && n_p != n_e) {
      if (n_e > n_p) {
        pad_n <- ai(n_e - n_p)
        pad <- strenv$jnp$zeros(list(pad_n), dtype = strenv$dtj)
        p_full <- strenv$jnp$concatenate(list(p_full, pad), axis = 0L)
      } else {
        p_full <- strenv$jnp$take(p_full, strenv$jnp$arange(ai(n_e)), axis = 0L)
      }
    }
    token_list[[d_]] <- strenv$jnp$einsum("l,lm->m", p_full, E_d)
  }
  tokens <- strenv$jnp$stack(token_list, axis = 0L)
  tokens <- add_party_rel_tokens(tokens,
                                 party_idx = party_idx,
                                 role_id = role_id,
                                 use_role = use_role,
                                 resp_party_idx = resp_party_idx,
                                 model_info = model_info,
                                 params = params)
  strenv$jnp$reshape(tokens, list(1L, tokens$shape[[1]], model_info$model_dims))
}

neural_build_context_tokens <- function(model_info,
                                        resp_party_idx = NULL,
                                        stage_idx = NULL,
                                        matchup_idx = NULL,
                                        resp_cov_vec = NULL,
                                        params = NULL){
  add_context_tokens(model_info = model_info,
                     resp_party_idx = resp_party_idx,
                     stage_idx = stage_idx,
                     matchup_idx = matchup_idx,
                     resp_cov = resp_cov_vec,
                     params = params,
                     batch = FALSE)
}

neural_build_choice_token <- function(model_info, params = NULL){
  if (is.null(params)) {
    params <- model_info$params
  }
  if (!is.null(params$E_choice)) {
    choice_vec <- params$E_choice
  } else {
    choice_vec <- strenv$jnp$zeros(list(ai(model_info$model_dims)), dtype = strenv$dtj)
  }
  strenv$jnp$reshape(choice_vec, list(1L, 1L, ai(model_info$model_dims)))
}

neural_run_transformer <- function(tokens, model_info, params = NULL){
  if (is.null(params)) {
    params <- model_info$params
  }
  for (l_ in 1L:ai(model_info$model_depth)) {
    Wq <- params[[paste0("W_q_l", l_)]]
    Wk <- params[[paste0("W_k_l", l_)]]
    Wv <- params[[paste0("W_v_l", l_)]]
    Wo <- params[[paste0("W_o_l", l_)]]
    Wff1 <- params[[paste0("W_ff1_l", l_)]]
    Wff2 <- params[[paste0("W_ff2_l", l_)]]
    RMS_attn <- params[[paste0("RMS_attn_l", l_)]]
    RMS_ff <- params[[paste0("RMS_ff_l", l_)]]
    alpha_attn <- neural_param_or_default(params, paste0("alpha_attn_l", l_), 1.0)
    alpha_ff <- neural_param_or_default(params, paste0("alpha_ff_l", l_), 1.0)

    tokens_norm <- neural_rms_norm(tokens, RMS_attn, model_info$model_dims)
    Q <- strenv$jnp$einsum("ntm,mk->ntk", tokens_norm, Wq)
    K <- strenv$jnp$einsum("ntm,mk->ntk", tokens_norm, Wk)
    V <- strenv$jnp$einsum("ntm,mk->ntk", tokens_norm, Wv)

    Qh <- strenv$jnp$reshape(Q, list(Q$shape[[1]], Q$shape[[2]],
                                    ai(model_info$n_heads), ai(model_info$head_dim)))
    Kh <- strenv$jnp$reshape(K, list(K$shape[[1]], K$shape[[2]],
                                    ai(model_info$n_heads), ai(model_info$head_dim)))
    Vh <- strenv$jnp$reshape(V, list(V$shape[[1]], V$shape[[2]],
                                    ai(model_info$n_heads), ai(model_info$head_dim)))
    scale_ <- strenv$jnp$sqrt(strenv$jnp$array(as.numeric(ai(model_info$head_dim))))
    scores <- strenv$jnp$einsum("nqhd,nkhd->nhqk", Qh, Kh) / scale_
    attn <- strenv$jax$nn$softmax(scores, axis = -1L)
    context_h <- strenv$jnp$einsum("nhqk,nkhd->nqhd", attn, Vh)
    context <- strenv$jnp$reshape(context_h, list(context_h$shape[[1]],
                                                  context_h$shape[[2]],
                                                  ai(model_info$model_dims)))
    attn_out <- strenv$jnp$einsum("ntm,mk->ntk", context, Wo)

    h1 <- tokens + alpha_attn * attn_out
    h1_norm <- neural_rms_norm(h1, RMS_ff, model_info$model_dims)
    ff_pre <- strenv$jnp$einsum("ntm,mf->ntf", h1_norm, Wff1)
    ff_act <- strenv$jax$nn$swish(ff_pre)
    ff_out <- strenv$jnp$einsum("ntf,fm->ntm", ff_act, Wff2)
    tokens <- h1 + alpha_ff * ff_out
  }
  tokens <- neural_rms_norm(tokens, params$RMS_final, model_info$model_dims)
  tokens
}

neural_encode_candidate_soft <- function(pi_vec, party_idx, model_info,
                                         resp_party_idx = NULL,
                                         stage_idx = NULL,
                                         matchup_idx = NULL,
                                         resp_cov_vec = NULL,
                                         params = NULL, use_role = FALSE){
  if (is.null(params)) {
    params <- model_info$params
  }
  choice_tok <- neural_build_choice_token(model_info, params)
  resp_tokens <- neural_build_context_tokens(model_info,
                                             resp_party_idx = resp_party_idx,
                                             stage_idx = stage_idx,
                                             matchup_idx = matchup_idx,
                                             resp_cov_vec = resp_cov_vec,
                                             params = params)
  cand_tokens <- neural_build_candidate_tokens_soft(pi_vec, party_idx, 0L, model_info, params,
                                                    use_role = use_role,
                                                    resp_party_idx = resp_party_idx)
  if (!is.null(resp_tokens)) {
    tokens <- strenv$jnp$concatenate(list(choice_tok, resp_tokens, cand_tokens), axis = 1L)
  } else {
    tokens <- strenv$jnp$concatenate(list(choice_tok, cand_tokens), axis = 1L)
  }
  tokens <- neural_run_transformer(tokens, model_info, params)
  choice_out <- strenv$jnp$take(tokens, strenv$jnp$arange(1L), axis = 1L)
  strenv$jnp$squeeze(choice_out, axis = 1L)
}

neural_candidate_utility_soft <- function(pi_vec, party_idx,
                                          resp_party_idx, stage_idx,
                                          model_info,
                                          resp_cov_vec = NULL,
                                          params = NULL,
                                          matchup_idx = NULL){
  if (is.null(params)) {
    params <- model_info$params
  }
  phi <- neural_encode_candidate_soft(pi_vec, party_idx, model_info,
                                      resp_party_idx = resp_party_idx,
                                      stage_idx = stage_idx,
                                      matchup_idx = matchup_idx,
                                      resp_cov_vec = resp_cov_vec,
                                      params = params)
  logits <- strenv$jnp$einsum("nm,mo->no", phi, params$W_out)
  if (!is.null(params$b_out)) {
    logits <- logits + params$b_out
  }
  logits
}

neural_predict_pair_soft <- function(pi_left, pi_right,
                                     party_left_idx, party_right_idx,
                                     resp_party_idx, model_info,
                                     resp_cov_vec = NULL,
                                     params = NULL,
                                     return_logits = FALSE){
  if (is.null(params)) {
    params <- model_info$params
  }
  mode <- neural_cross_encoder_mode(model_info)
  use_cross_encoder <- identical(mode, "full")
  use_cross_term <- identical(mode, "term")
  stage_idx <- neural_stage_index(party_left_idx, party_right_idx, model_info)
  matchup_idx <- NULL
  if (!is.null(params$E_matchup)) {
    matchup_idx <- neural_matchup_index(party_left_idx, party_right_idx, model_info)
  }
  if (isTRUE(use_cross_encoder)) {
    choice_tok <- neural_build_choice_token(model_info, params)
    ctx_tokens <- neural_build_context_tokens(model_info,
                                              resp_party_idx = resp_party_idx,
                                              stage_idx = stage_idx,
                                              matchup_idx = matchup_idx,
                                              resp_cov_vec = resp_cov_vec,
                                              params = params)
    left_tokens <- neural_add_segment_embedding(
      neural_build_candidate_tokens_soft(pi_left, party_left_idx, 0L, model_info, params,
                                         resp_party_idx = resp_party_idx),
      0L,
      model_info = model_info,
      params = params
    )
    right_tokens <- neural_add_segment_embedding(
      neural_build_candidate_tokens_soft(pi_right, party_right_idx, 1L, model_info, params,
                                         resp_party_idx = resp_party_idx),
      1L,
      model_info = model_info,
      params = params
    )
    sep_tok <- neural_build_sep_token(model_info, params = params)
    token_parts <- list(choice_tok)
    if (!is.null(ctx_tokens)) {
      token_parts <- c(token_parts, list(ctx_tokens))
    }
    token_parts <- c(token_parts, list(sep_tok, left_tokens, sep_tok, right_tokens))
    tokens <- strenv$jnp$concatenate(token_parts, axis = 1L)
    tokens <- neural_run_transformer(tokens, model_info, params)
    cls_out <- strenv$jnp$take(tokens, strenv$jnp$arange(1L), axis = 1L)
    cls_out <- strenv$jnp$squeeze(cls_out, axis = 1L)
    logits <- strenv$jnp$einsum("nm,mo->no", cls_out, params$W_out)
    if (!is.null(params$b_out)) {
      logits <- logits + params$b_out
    }
  } else {
    phi_left <- neural_encode_candidate_soft(pi_left, party_left_idx, model_info,
                                             resp_party_idx = resp_party_idx,
                                             stage_idx = stage_idx,
                                             matchup_idx = matchup_idx,
                                             resp_cov_vec = resp_cov_vec,
                                             params = params)
    phi_right <- neural_encode_candidate_soft(pi_right, party_right_idx, model_info,
                                              resp_party_idx = resp_party_idx,
                                              stage_idx = stage_idx,
                                              matchup_idx = matchup_idx,
                                              resp_cov_vec = resp_cov_vec,
                                              params = params)
    u_left <- strenv$jnp$einsum("nm,mo->no", phi_left, params$W_out)
    if (!is.null(params$b_out)) {
      u_left <- u_left + params$b_out
    }
    u_right <- strenv$jnp$einsum("nm,mo->no", phi_right, params$W_out)
    if (!is.null(params$b_out)) {
      u_right <- u_right + params$b_out
    }
    logits <- u_left - u_right
    if (isTRUE(use_cross_term) && !is.null(params$M_cross)) {
      cross_term <- strenv$jnp$einsum("nm,mp,np->n", phi_left, params$M_cross, phi_right)
      cross_term <- strenv$jnp$reshape(cross_term, list(-1L, 1L))
      cross_out <- if (!is.null(params$W_cross_out)) {
        strenv$jnp$reshape(params$W_cross_out, list(1L, -1L))
      } else {
        strenv$jnp$zeros(list(1L, ai(params$W_out$shape[[2]])), dtype = strenv$dtj)
      }
      logits <- logits + cross_term * cross_out
    }
  }
  if (return_logits) {
    return(logits)
  }
  neural_logits_to_q(logits, model_info$likelihood)
}

neural_predict_single_soft <- function(pi_vec,
                                       party_idx,
                                       resp_party_idx,
                                       model_info,
                                       resp_cov_vec = NULL,
                                       params = NULL){
  logits <- neural_candidate_utility_soft(pi_vec, party_idx,
                                          resp_party_idx, stage_idx = NULL,
                                          model_info = model_info,
                                          resp_cov_vec = resp_cov_vec,
                                          params = params)
  neural_logits_to_q(logits, model_info$likelihood)
}

neural_getQStar_single <- function(pi_star_ast,
                                   EST_COEFFICIENTS_tf_ast) {
  if (!exists("neural_model_info_ast_jnp", inherits = TRUE)) {
    stop("neural_getQStar_single requires neural_model_info_ast_jnp.", call. = FALSE)
  }
  model_ast <- get("neural_model_info_ast_jnp", inherits = TRUE)
  party_label <- if (exists("GroupsPool", inherits = TRUE) && length(GroupsPool) > 0) {
    GroupsPool[1]
  } else {
    NULL
  }
  party_idx <- neural_get_party_index(model_ast, party_label)
  resp_idx <- neural_get_resp_party_index(model_ast, party_label)
  params_ast <- neural_params_from_theta(EST_COEFFICIENTS_tf_ast, model_ast)
  Qhat <- neural_predict_single_soft(pi_star_ast, party_idx, resp_idx, model_ast,
                                     params = params_ast)
  strenv$jnp$concatenate(list(Qhat, Qhat, Qhat), 0L)
}

neural_getQStar_diff_BASE <- function(pi_star_ast, pi_star_dag,
                                      EST_COEFFICIENTS_tf_ast,
                                      EST_COEFFICIENTS_tf_dag) {
  if (!exists("neural_model_info_ast_jnp", inherits = TRUE)) {
    stop("neural_getQStar_diff_BASE requires neural_model_info_ast_jnp.", call. = FALSE)
  }
  model_ast <- get("neural_model_info_ast_jnp", inherits = TRUE)
  model_dag <- if (exists("neural_model_info_dag_jnp", inherits = TRUE)) {
    get("neural_model_info_dag_jnp", inherits = TRUE)
  } else {
    model_ast
  }

  party_label_ast <- if (exists("GroupsPool", inherits = TRUE) && length(GroupsPool) > 0) {
    GroupsPool[1]
  } else {
    NULL
  }
  party_label_dag <- if (exists("GroupsPool", inherits = TRUE) && length(GroupsPool) > 1) {
    GroupsPool[2]
  } else {
    party_label_ast
  }

  party_idx_ast <- neural_get_party_index(model_ast, party_label_ast)
  party_idx_dag <- neural_get_party_index(model_dag, party_label_dag)
  resp_idx_ast <- neural_get_resp_party_index(model_ast, party_label_ast)
  resp_idx_dag <- neural_get_resp_party_index(model_dag, party_label_dag)
  params_ast <- neural_params_from_theta(EST_COEFFICIENTS_tf_ast, model_ast)
  params_dag <- neural_params_from_theta(EST_COEFFICIENTS_tf_dag, model_dag)

  if (exists("Q_DISAGGREGATE", inherits = TRUE) && !isTRUE(Q_DISAGGREGATE)) {
    resp_idx_dag <- resp_idx_ast
    params_dag <- params_ast
  }

  Qhat_ast_among_ast <- neural_predict_pair_soft(
    pi_star_ast, pi_star_dag,
    party_idx_ast, party_idx_dag,
    resp_idx_ast, model_ast,
    params = params_ast
  )

  if (exists("Q_DISAGGREGATE", inherits = TRUE) && !isTRUE(Q_DISAGGREGATE)) {
    Qhat_population <- Qhat_ast_among_dag <- Qhat_ast_among_ast
  } else {
    Qhat_ast_among_dag <- neural_predict_pair_soft(
      pi_star_ast, pi_star_dag,
      party_idx_ast, party_idx_dag,
      resp_idx_dag, model_dag,
      params = params_dag
    )
    Qhat_population <- Qhat_ast_among_ast * strenv$jnp$array(strenv$AstProp) +
      Qhat_ast_among_dag * strenv$jnp$array(strenv$DagProp)
  }

  strenv$jnp$concatenate(list(Qhat_population,
                              Qhat_ast_among_ast,
                              Qhat_ast_among_dag), 0L)
}

cs2step_build_pair_mat <- function(pair_id,
                                   W,
                                   profile_order = NULL,
                                   competing_group_variable_candidate = NULL) {
  if (is.null(pair_id) || !length(pair_id)) {
    return(NULL)
  }
  if (is.null(W) || !length(W)) {
    stop("cs2step_build_pair_mat requires a non-empty W.", call. = FALSE)
  }
  W <- as.matrix(W)
  pair_id <- as.vector(pair_id)
  if (length(pair_id) != nrow(W)) {
    stop(sprintf("pair_id has %d elements but W has %d rows.",
                 length(pair_id), nrow(W)),
         call. = FALSE)
  }

  pair_indices_list <- tapply(seq_along(pair_id), pair_id, c)
  profile_order_present <- !is.null(profile_order) &&
    length(profile_order) == length(pair_id)

  row_key <- apply(W, 1, function(row) {
    paste(ifelse(is.na(row), "NA", as.character(row)), collapse = "|")
  })
  row_hash <- vapply(row_key, function(key) {
    ints <- utf8ToInt(key)
    if (!length(ints)) {
      return(0)
    }
    sum(ints * seq_along(ints)) %% 2147483647
  }, numeric(1))

  pair_mat <- do.call(rbind, lapply(pair_indices_list, function(idx){
    order_by_profile <- profile_order_present &&
      length(idx) == 2L &&
      length(unique(profile_order[idx])) == 2L &&
      !any(is.na(profile_order[idx]))
    if (!is.null(competing_group_variable_candidate)) {
      if (order_by_profile) {
        idx[order(competing_group_variable_candidate[idx],
                  profile_order[idx],
                  row_hash[idx],
                  idx)]
      } else {
        idx[order(competing_group_variable_candidate[idx],
                  row_hash[idx],
                  idx)]
      }
    } else if (order_by_profile) {
      idx[order(profile_order[idx],
                row_hash[idx],
                idx)]
    } else {
      idx[order(row_hash[idx], idx)]
    }
  }))

  list(
    pair_mat = pair_mat,
    pair_sizes = lengths(pair_indices_list),
    profile_order_present = profile_order_present
  )
}

generate_ModelOutcome_neural <- function(){
  message("Defining MCMC parameters in generate_ModelOutcome_neural...")
  mcmc_control <- list(
    backend = "numpyro",
    n_samples_warmup = 500L,
    n_samples_mcmc   = 1000L,
    batch_size = 512L,
    chain_method = "parallel",
    subsample_method = "full",
    n_thin_by = 1L,
    n_chains = 2L,
    svi_steps = 1000L,
    svi_lr = 0.01,
    svi_num_particles = 1L,
    svi_num_draws = 200L,
    vi_guide = "auto_diagonal",
    optimizer = "adam",
    svi_lr_schedule = "warmup_cosine",
    svi_lr_warmup_frac = 0.1,
    svi_lr_end_factor = 0.01
  )
  RMS_scale = 0.35
  UsedRegularization <- FALSE
  uncertainty_scope <- "all"
  mcmc_overrides <- NULL
  eval_control <- list(enabled = TRUE, max_n = NULL, seed = 123L)
  model_dims <- 128L
  model_depth <- 2L
  cross_candidate_encoder_mode <- "none"
  warn_stage_imbalance_pct <- 0.10
  warn_min_cell_n <- 50L
  normalize_cross_candidate_encoder <- function(value) {
    if (is.null(value)) {
      return("none")
    }
    if (isTRUE(value)) {
      return("term")
    }
    if (identical(value, FALSE)) {
      return("none")
    }
    if (is.character(value)) {
      mode <- tolower(as.character(value))
      if (length(mode) != 1L || is.na(mode) || !nzchar(mode)) {
        stop(
          "'neural_mcmc_control$cross_candidate_encoder' must be TRUE/FALSE or one of ",
          "'none', 'term', or 'full'.",
          call. = FALSE
        )
      }
      if (mode %in% c("none", "term", "full")) {
        return(mode)
      }
      if (mode %in% c("true", "false")) {
        return(ifelse(mode == "true", "term", "none"))
      }
    }
    stop(
      "'neural_mcmc_control$cross_candidate_encoder' must be TRUE/FALSE or one of ",
      "'none', 'term', or 'full'.",
      call. = FALSE
    )
  }
  if (exists("neural_mcmc_control", inherits = TRUE) &&
      !is.null(neural_mcmc_control)) {
    if (!is.list(neural_mcmc_control)) {
      stop("'neural_mcmc_control' must be a list.", call. = FALSE)
    }
    if (!is.null(neural_mcmc_control$uncertainty_scope)) {
      uncertainty_scope <- tolower(as.character(neural_mcmc_control$uncertainty_scope))
    }
    if (!is.null(neural_mcmc_control$eval_enabled)) {
      eval_control$enabled <- isTRUE(neural_mcmc_control$eval_enabled)
    }
    if (!is.null(neural_mcmc_control$eval_max_n)) {
      eval_control$max_n <- as.integer(neural_mcmc_control$eval_max_n)
    }
    if (!is.null(neural_mcmc_control$eval_seed)) {
      eval_control$seed <- as.integer(neural_mcmc_control$eval_seed)
    }
    if (!is.null(neural_mcmc_control$ModelDims)) {
      model_dims <- neural_mcmc_control$ModelDims
    }
    if (!is.null(neural_mcmc_control$ModelDepth)) {
      model_depth <- neural_mcmc_control$ModelDepth
    }
    if (!is.null(neural_mcmc_control$cross_candidate_encoder)) {
      cross_candidate_encoder_mode <- normalize_cross_candidate_encoder(
        neural_mcmc_control$cross_candidate_encoder
      )
    }
    if (!is.null(neural_mcmc_control$warn_stage_imbalance_pct)) {
      warn_stage_imbalance_pct <- as.numeric(neural_mcmc_control$warn_stage_imbalance_pct)
    }
    if (!is.null(neural_mcmc_control$warn_min_cell_n)) {
      warn_min_cell_n <- as.integer(neural_mcmc_control$warn_min_cell_n)
    }
    mcmc_overrides <- neural_mcmc_control
    mcmc_overrides$uncertainty_scope <- NULL
    mcmc_overrides$n_bayesian_models <- NULL
    mcmc_overrides$ModelDims <- NULL
    mcmc_overrides$ModelDepth <- NULL
    mcmc_overrides$cross_candidate_encoder <- NULL
  }
  uncertainty_scope_env <- Sys.getenv("STRATEGIZE_NEURAL_UNCERTAINTY_SCOPE")
  if (nzchar(uncertainty_scope_env)) {
    uncertainty_scope <- tolower(as.character(uncertainty_scope_env))
  }
  fast_mcmc_flag <- tolower(Sys.getenv("STRATEGIZE_NEURAL_FAST_MCMC")) %in%
    c("1", "true", "yes")
  if (isTRUE(fast_mcmc_flag)) {
    mcmc_control$n_samples_warmup <- 50L
    mcmc_control$n_samples_mcmc <- 50L
    mcmc_control$batch_size <- 128L
    mcmc_control$n_chains <- 1L
    mcmc_control$chain_method <- "sequential"
    mcmc_control$svi_steps <- 200L
    mcmc_control$svi_num_draws <- 100L
  }
  if (!is.null(mcmc_overrides) && length(mcmc_overrides) > 0) {
    mcmc_control <- modifyList(mcmc_control, mcmc_overrides)
  }
  skip_eval_flag <- tolower(Sys.getenv("STRATEGIZE_NEURAL_SKIP_EVAL")) %in%
    c("1", "true", "yes")
  if (isTRUE(skip_eval_flag)) {
    eval_control$enabled <- FALSE
  }
  eval_max_env <- suppressWarnings(as.integer(Sys.getenv("STRATEGIZE_NEURAL_EVAL_MAX")))
  if (!is.na(eval_max_env) && eval_max_env > 0L) {
    eval_control$max_n <- eval_max_env
  }
  if (!uncertainty_scope %in% c("all", "output")) {
    stop("'neural_mcmc_control$uncertainty_scope' must be 'all' or 'output'.",
         call. = FALSE)
  }
  subsample_method <- if (!is.null(mcmc_control$subsample_method)) {
    tolower(as.character(mcmc_control$subsample_method))
  } else {
    "full"
  }
  if (length(subsample_method) != 1L || is.na(subsample_method) || !nzchar(subsample_method)) {
    subsample_method <- "full"
  }
  mcmc_control$subsample_method <- subsample_method

  if (!is.numeric(model_dims) || length(model_dims) != 1L || !is.finite(model_dims)) {
    stop("'neural_mcmc_control$ModelDims' must be a single finite numeric value.",
         call. = FALSE)
  }
  if (model_dims != round(model_dims) || model_dims < 1L) {
    stop("'neural_mcmc_control$ModelDims' must be an integer >= 1.",
         call. = FALSE)
  }
  if (!is.numeric(model_depth) || length(model_depth) != 1L || !is.finite(model_depth)) {
    stop("'neural_mcmc_control$ModelDepth' must be a single finite numeric value.",
         call. = FALSE)
  }
  if (model_depth != round(model_depth) || model_depth < 1L) {
    stop("'neural_mcmc_control$ModelDepth' must be an integer >= 1.",
         call. = FALSE)
  }
  # Hyperparameters
  ModelDims  <- ai(model_dims)
  ModelDepth <- ai(model_depth)
  WideMultiplicationFactor <- 3.75
  MD_int <- ai(ModelDims)
  cand_heads <- (1:MD_int)[(MD_int %% (1:MD_int)) == 0L]
  TransformerHeads <- ai(cand_heads[which.min(abs(cand_heads - 8L))])
  head_dim <- ai(ai(MD_int / TransformerHeads))
  FFDim <- ai(ai(round(MD_int * WideMultiplicationFactor)))
  weight_sd_scale <- sqrt(2) / sqrt(as.numeric(ModelDims))
  #weight_sd_scale <- sqrt(2 * log(1 + ModelDims/2))/sqrt(ModelDims)
  
  # Depth-aware scaling for priors and ReZero-style residual gates.
  depth_prior_scale <- 1 / sqrt(as.numeric(ModelDepth))
  gate_sd_scale <- 0.1 * depth_prior_scale
  embed_sd_scale <- 4 * weight_sd_scale
  factor_embed_sd_scale <- embed_sd_scale
  context_embed_sd_scale <- embed_sd_scale
  tau_b_scale <- 0.5
  
  # shrink M_cross more (initialize interactionto smaller than main temr)
  # cross_out does NOT need to shrink with ModelDims (doesn't scale with that)
  cross_weight_sd_scale <- weight_sd_scale / sqrt(as.numeric(ModelDims))
  cross_out_sd_scale    <- 0.5  # or 0.25 if you want it more conservative

  # Pairwise mode for forced-choice
  pairwise_mode <- isTRUE(diff) && !is.null(pair_id_) && length(pair_id_) > 0
  if (!isTRUE(pairwise_mode)) {
    cross_candidate_encoder_mode <- "none"
  }
  use_cross_term <- identical(cross_candidate_encoder_mode, "term")
  use_cross_encoder <- identical(cross_candidate_encoder_mode, "full")
  use_matchup_token <- isTRUE(pairwise_mode) &&
    !identical(cross_candidate_encoder_mode, "none")

  # Main-info structure for downstream compatibility
  for(nrp in 1:2){
    main_info <- do.call(rbind, sapply(1:length(factor_levels), function(d_){
      list(data.frame(
        "d" = d_,
        "l" = 1:max(1, factor_levels[d_] - ifelse(nrp == 1, yes = 1, no = holdout_indicator))
      ))
    }))
    main_info <- cbind(main_info, "d_index" = 1:nrow(main_info))
    if(nrp == 1){ a_structure <- main_info }
  }
  if(holdout_indicator == 0){
    a_structure_leftoutLdminus1 <- main_info[which(c(base::diff(main_info$d),1)==0),]
    a_structure_leftoutLdminus1$d_index <- 1:nrow(a_structure_leftoutLdminus1)
  }

  interaction_info <- data.frame()
  interaction_info_PreRegularization <- interaction_info
  regularization_adjust_hash <- main_info$d
  names(regularization_adjust_hash) <- main_info$d

  factor_levels_int <- as.integer(factor_levels)
  factor_levels_aug <- factor_levels_int + 1L
  factor_index_list <- vector("list", length(factor_levels))
  offset <- 0L
  for (d_ in seq_along(factor_levels)) {
    n_levels_use <- ai(factor_levels[d_] - holdout_indicator)
    idx <- if (n_levels_use > 0L) {
      as.integer(offset + seq_len(n_levels_use) - 1L)
    } else {
      integer(0)
    }
    factor_index_list[[d_]] <- strenv$jnp$array(idx)$astype(strenv$jnp$int32)
    offset <- offset + n_levels_use
  }
  n_rel_levels <- ai(3L)
  n_candidate_tokens <- ai(length(factor_levels) + 2L)

  # Party token mapping (candidates)
  party_levels <- if (!is.null(competing_group_variable_candidate_)) {
    sort(unique(as.character(competing_group_variable_candidate_)))
  } else {
    "NA"
  }
  n_party_levels <- max(1L, length(party_levels))
  n_matchup_levels <- if (isTRUE(use_matchup_token)) {
    as.integer(n_party_levels * (n_party_levels + 1L) / 2L)
  } else {
    0L
  }
  party_index <- if (!is.null(competing_group_variable_candidate_)) {
    match(as.character(competing_group_variable_candidate_), party_levels) - 1L
  } else {
    rep(0L, length(Y_))
  }
  party_index[is.na(party_index)] <- 0L

  # Respondent party mapping
  resp_party_levels <- if (!is.null(competing_group_variable_respondent_)) {
    sort(unique(as.character(competing_group_variable_respondent_)))
  } else {
    "NA"
  }
  n_resp_party_levels <- max(1L, length(resp_party_levels))
  resp_party_index <- if (!is.null(competing_group_variable_respondent_)) {
    match(as.character(competing_group_variable_respondent_), resp_party_levels) - 1L
  } else {
    rep(0L, length(Y_))
  }
  resp_party_index[is.na(resp_party_index)] <- 0L

  cand_party_to_resp_idx <- vapply(party_levels, function(party_label) {
    idx <- match(as.character(party_label), resp_party_levels)
    if (is.na(idx)) -1L else as.integer(idx - 1L)
  }, integer(1))
  cand_party_to_resp_idx_jnp <- strenv$jnp$array(as.integer(cand_party_to_resp_idx))
  cand_party_to_resp_idx_jnp <- strenv$jnp$atleast_1d(cand_party_to_resp_idx_jnp)$astype(strenv$jnp$int32)

  # Respondent covariates (optional)
  X_use <- NULL
  X_ <- NULL
  if (exists("X", inherits = TRUE) && !is.null(X)) {
    X_ <- as.matrix(X[indi_, , drop = FALSE])
  }

  # Helper to sanitize integer indices (adds explicit missing/OOV level per factor)
  to_index_matrix <- function(x_mat){
    x_mat <- as.matrix(x_mat)
    x_int <- matrix(as.integer(x_mat), nrow = nrow(x_mat), ncol = ncol(x_mat))
    n_cols <- ncol(x_int)
    n_levels <- factor_levels_int
    if (length(n_levels) != n_cols) {
      n_levels <- rep_len(n_levels, n_cols)
    }
    for (d_ in seq_len(n_cols)) {
      max_level <- n_levels[[d_]]
      missing_level <- max_level + 1L
      col_vals <- x_int[, d_]
      col_vals[is.na(col_vals) | col_vals < 1L | col_vals > max_level] <- missing_level
      x_int[, d_] <- col_vals - 1L
    }
    x_int
  }

  center_factor_embeddings <- function(E_factor_raw, n_real_levels) {
    n_real_levels <- ai(n_real_levels)
    real_idx <- strenv$jnp$arange(n_real_levels)
    real_rows <- strenv$jnp$take(E_factor_raw, real_idx, axis = 0L)
    real_mean <- strenv$jnp$mean(real_rows, axis = 0L, keepdims = TRUE)
    real_centered <- real_rows - real_mean
    missing_row <- strenv$jnp$take(E_factor_raw, ai(n_real_levels), axis = 0L)
    missing_row <- strenv$jnp$reshape(missing_row, list(1L, ModelDims))
    strenv$jnp$concatenate(list(real_centered, missing_row), axis = 0L)
  }

  # Build pairwise or single-candidate data
  pair_mat <- NULL
  if (pairwise_mode) {
    pair_info <- cs2step_build_pair_mat(
      pair_id = pair_id_,
      W = W_,
      profile_order = profile_order_,
      competing_group_variable_candidate = competing_group_variable_candidate_
    )
    if (is.null(pair_info) || is.null(pair_info$pair_sizes) ||
        !all(pair_info$pair_sizes == 2L)) {
      warning("pair_id does not define exactly 2 rows per pair; falling back to single-candidate model.")
      pairwise_mode <- FALSE
    } else {
      pair_mat <- pair_info$pair_mat
    }
  }

  if (pairwise_mode) {
    X_left <- W_[pair_mat[,1], , drop = FALSE]
    X_right <- W_[pair_mat[,2], , drop = FALSE]
    Y_use <- Y_[pair_mat[,1]]
    party_left <- party_index[pair_mat[,1]]
    party_right <- party_index[pair_mat[,2]]
    resp_party_use <- resp_party_index[pair_mat[,1]]
    if (!is.null(X_)) {
      X_use <- X_[pair_mat[,1], , drop = FALSE]
    }
  } else {
    X_single <- W_
    Y_use <- Y_
    party_single <- party_index
    resp_party_use <- resp_party_index
    X_use <- X_
  }

  stage_diagnostics <- NULL
  if (pairwise_mode) {
    stage_is_primary <- party_left == party_right
    n_total <- length(stage_is_primary)
    n_primary <- if (n_total > 0L) sum(stage_is_primary, na.rm = TRUE) else 0L
    n_general <- if (n_total > 0L) sum(!stage_is_primary, na.rm = TRUE) else 0L
    pct_primary <- if (n_total > 0L) n_primary / n_total else NA_real_
    stage_label <- ifelse(stage_is_primary, "primary", "general")
    resp_party_label <- if (!is.null(resp_party_levels)) {
      idx <- as.integer(resp_party_use) + 1L
      idx[idx < 1L | idx > length(resp_party_levels)] <- NA_integer_
      resp_party_levels[idx]
    } else {
      as.character(resp_party_use)
    }
    stage_table <- table(resp_party_label, stage_label)
    cell_counts <- as.integer(stage_table)
    min_cell_n <- if (length(cell_counts) > 0L) min(cell_counts) else NA_integer_
    single_stage_only <- isTRUE(pct_primary == 0 || pct_primary == 1)
    warn_stage_imbalance <- is.finite(pct_primary) &&
      (pct_primary < warn_stage_imbalance_pct || pct_primary > (1 - warn_stage_imbalance_pct))
    warn_sparse_cells <- !is.na(min_cell_n) && min_cell_n < warn_min_cell_n

    if (isTRUE(warn_stage_imbalance)) {
      warning(
        sprintf("Stage imbalance detected in neural training data (pct_primary=%.3f).", pct_primary),
        call. = FALSE
      )
    }
    if (isTRUE(warn_sparse_cells)) {
      warning(
        sprintf("Sparse stage/resp-party cells detected (min cell n=%d).", min_cell_n),
        call. = FALSE
      )
    }
    if (isTRUE(single_stage_only)) {
      warning(
        "Stage indicator has no variation; E_stage is not identified for the unused stage.",
        call. = FALSE
      )
    }

    stage_diagnostics <- list(
      n_primary = as.integer(n_primary),
      n_general = as.integer(n_general),
      pct_primary = pct_primary,
      resp_party_stage_table = stage_table,
      single_stage_only = single_stage_only,
      sparse_cells = warn_sparse_cells,
      min_cell_n = min_cell_n,
      warn_stage_imbalance_pct = warn_stage_imbalance_pct,
      warn_min_cell_n = warn_min_cell_n
    )
  }

  n_resp_covariates <- if (!is.null(X_use)) ai(ncol(X_use)) else ai(0L)
  resp_cov_sd <- if (n_resp_covariates > 0L) {
    0.5 / sqrt(as.numeric(n_resp_covariates))
  } else {
    NULL
  }
  resp_cov_mean <- if (!is.null(X_use) && n_resp_covariates > 0L) {
    as.numeric(colMeans(X_use))
  } else {
    NULL
  }

  # Placeholder to keep model chunks consistent (no surrogate regression)
  main_dat <- matrix(0, nrow = 0L, ncol = 0L)

  # Likelihood selection
  is_binary <- all(unique(na.omit(as.numeric(Y_use))) %in% c(0, 1)) &&
    length(unique(na.omit(Y_use))) <= 2
  is_intvec <- all(!is.na(Y_use)) && all(abs(Y_use - round(Y_use)) < 1e-8)
  K_classes <- if (is_intvec) length(unique(ai(Y_use))) else NA_integer_

  if (is_binary) {
    likelihood <- "bernoulli"; nOutcomes <- ai(1L)
  } else if (!is.na(K_classes) && K_classes >= 2L && K_classes <= max(50L, ncol(W_) + 1L)) {
    likelihood <- "categorical"; nOutcomes <- ai(K_classes)
  } else {
    likelihood <- "normal"; nOutcomes <- ai(1L)
  }
  sigma_prior_scale <- 1.0
  if (likelihood == "normal") {
    y_numeric <- as.numeric(Y_use)
    y_mad <- suppressWarnings(stats::mad(y_numeric, na.rm = TRUE))
    y_sd <- suppressWarnings(stats::sd(y_numeric, na.rm = TRUE))
    sigma_prior_scale <- if (is.finite(y_mad) && y_mad > 0) {
      y_mad
    } else if (is.finite(y_sd) && y_sd > 0) {
      y_sd
    } else {
      1.0
    }
  }

  pdtype_ <- ddtype_ <- strenv$jnp$float32
  manual_noncentered_loc_scale <- FALSE
  p2d_eps <- 1e-6
  p2d_hash31 <- function(x, mod = 2147483647) {
    bytes <- utf8ToInt(as.character(x))
    h <- 0
    for (b in bytes) {
      h <- (h * 31 + b) %% mod
    }
    if (!is.finite(h) || is.na(h) || h < 0) {
      h <- 0
    }
    as.integer(h)
  }
  p2d_draw_fixed_normal <- function(name, scale, shape_tuple, dtype = ddtype_) {
    seed <- p2d_hash31(paste0("p2d:", name))
    key <- strenv$jax$random$PRNGKey(ai(seed))
    draw <- strenv$jax$random$normal(key, shape = shape_tuple, dtype = dtype)
    as.numeric(scale) * draw
  }
  p2d_init_normal <- function(name, scale, shape_tuple, dtype = ddtype_) {
    p2d_draw_fixed_normal(paste0(name, ":init"), scale, shape_tuple, dtype = dtype)
  }
  p2d_init_halfnormal <- function(name, scale, shape_tuple, dtype = ddtype_) {
    strenv$jnp$abs(p2d_draw_fixed_normal(paste0(name, ":init"), scale, shape_tuple, dtype = dtype)) + p2d_eps
  }
  p2d_init_lognormal <- function(name, sd, shape_tuple, dtype = ddtype_) {
    strenv$jnp$exp(p2d_draw_fixed_normal(paste0(name, ":init_log"), sd, shape_tuple, dtype = dtype)) + p2d_eps
  }
  p2d_constraint_positive <- NULL
  if (!is.null(strenv$numpyro$distributions) &&
      reticulate::py_has_attr(strenv$numpyro$distributions, "constraints")) {
    constraints_mod <- strenv$numpyro$distributions$constraints
    if (!is.null(constraints_mod) && reticulate::py_has_attr(constraints_mod, "positive")) {
      p2d_constraint_positive <- constraints_mod$positive
    }
  }
  p2d <- function(name,
                  sample_fxn,
                  init_fxn,
                  constraint = NULL,
                  uncertainty_scope_arg = uncertainty_scope,
                  is_output_layer = FALSE) {
    scope <- tolower(as.character(uncertainty_scope_arg))
    if (identical(scope, "output") && !isTRUE(is_output_layer)) {
      init_val <- init_fxn()
      if (!is.null(constraint)) {
        return(strenv$numpyro$param(name, init_val, constraint = constraint))
      }
      return(strenv$numpyro$param(name, init_val))
    }
    sample_fxn()
  }
  sample_loc_scale <- function(name, scale, shape_tuple) {
    if (isTRUE(manual_noncentered_loc_scale)) {
      z <- strenv$numpyro$sample(
        paste0(name, "_z"),
        strenv$numpyro$distributions$Normal(0., 1.)$expand(shape_tuple)
      )
      strenv$numpyro$deterministic(name, scale * z)
    } else {
      strenv$numpyro$sample(
        name,
        strenv$numpyro$distributions$Normal(0., scale)$expand(shape_tuple)
      )
    }
  }

  sample_shared_transformer_params <- function(D_local, pairwise = FALSE) {
    output_only_mode <- identical(tolower(as.character(uncertainty_scope)), "output")

    tau_factor <- if (isTRUE(output_only_mode)) {
      as.numeric(factor_embed_sd_scale)
    } else {
      strenv$numpyro$sample(
        "tau_factor",
        strenv$numpyro$distributions$HalfNormal(as.numeric(factor_embed_sd_scale))
      )
    }
    tau_context <- if (isTRUE(output_only_mode)) {
      as.numeric(context_embed_sd_scale)
    } else {
      strenv$numpyro$sample(
        "tau_context",
        strenv$numpyro$distributions$HalfNormal(as.numeric(context_embed_sd_scale))
      )
    }

    E_factor_list <- vector("list", D_local)
    for (d_ in 1L:D_local) {
      raw_name <- paste0("E_factor_", d_, "_raw")
      raw_shape <- reticulate::tuple(ai(factor_levels_aug[d_]), ModelDims)
      E_factor_raw <- p2d(
        name = raw_name,
        sample_fxn = function() {
          strenv$numpyro$sample(
            raw_name,
            strenv$numpyro$distributions$Normal(0., tau_factor),
            sample_shape = raw_shape
          )
        },
        init_fxn = function() {
          p2d_init_normal(raw_name, tau_factor, raw_shape)
        }
      )
      E_factor_centered <- center_factor_embeddings(E_factor_raw, factor_levels_int[d_])
      E_factor_list[[d_]] <- strenv$numpyro$deterministic(
        paste0("E_factor_", d_),
        E_factor_centered
      )
    }

    E_feature_shape <- reticulate::tuple(ai(D_local), ModelDims)
    E_feature_id <- p2d(
      name = "E_feature_id",
      sample_fxn = function() {
        strenv$numpyro$sample(
          "E_feature_id",
          strenv$numpyro$distributions$Normal(0., tau_context),
          sample_shape = E_feature_shape
        )
      },
      init_fxn = function() {
        p2d_init_normal("E_feature_id", tau_context, E_feature_shape)
      }
    )

    E_party_shape <- reticulate::tuple(ai(n_party_levels), ModelDims)
    E_party <- p2d(
      name = "E_party",
      sample_fxn = function() {
        strenv$numpyro$sample(
          "E_party",
          strenv$numpyro$distributions$Normal(0., tau_context),
          sample_shape = E_party_shape
        )
      },
      init_fxn = function() {
        p2d_init_normal("E_party", tau_context, E_party_shape)
      }
    )

    E_rel_shape <- reticulate::tuple(ai(n_rel_levels), ModelDims)
    E_rel <- p2d(
      name = "E_rel",
      sample_fxn = function() {
        strenv$numpyro$sample(
          "E_rel",
          strenv$numpyro$distributions$Normal(0., tau_context),
          sample_shape = E_rel_shape
        )
      },
      init_fxn = function() {
        p2d_init_normal("E_rel", tau_context, E_rel_shape)
      }
    )

    E_resp_party_shape <- reticulate::tuple(ai(n_resp_party_levels), ModelDims)
    E_resp_party <- p2d(
      name = "E_resp_party",
      sample_fxn = function() {
        strenv$numpyro$sample(
          "E_resp_party",
          strenv$numpyro$distributions$Normal(0., tau_context),
          sample_shape = E_resp_party_shape
        )
      },
      init_fxn = function() {
        p2d_init_normal("E_resp_party", tau_context, E_resp_party_shape)
      }
    )

    E_stage <- NULL
    E_matchup <- NULL
    if (isTRUE(pairwise)) {
      E_stage_shape <- reticulate::tuple(ai(n_resp_party_levels), ai(2L), ModelDims)
      E_stage <- p2d(
        name = "E_stage",
        sample_fxn = function() {
          strenv$numpyro$sample(
            "E_stage",
            strenv$numpyro$distributions$Normal(0., tau_context),
            sample_shape = E_stage_shape
          )
        },
        init_fxn = function() {
          p2d_init_normal("E_stage", tau_context, E_stage_shape)
        }
      )
      if (isTRUE(use_matchup_token)) {
        E_matchup_shape <- reticulate::tuple(ai(n_matchup_levels), ModelDims)
        E_matchup <- p2d(
          name = "E_matchup",
          sample_fxn = function() {
            strenv$numpyro$sample(
              "E_matchup",
              strenv$numpyro$distributions$Normal(0., tau_context),
              sample_shape = E_matchup_shape
            )
          },
          init_fxn = function() {
            p2d_init_normal("E_matchup", tau_context, E_matchup_shape)
          }
        )
      }
    }

    E_choice_shape <- reticulate::tuple(ModelDims)
    E_choice <- p2d(
      name = "E_choice",
      sample_fxn = function() {
        strenv$numpyro$sample(
          "E_choice",
          strenv$numpyro$distributions$Normal(0., tau_context),
          sample_shape = E_choice_shape
        )
      },
      init_fxn = function() {
        p2d_init_normal("E_choice", tau_context, E_choice_shape)
      }
    )

    E_sep <- NULL
    E_segment <- NULL
    if (isTRUE(pairwise) && isTRUE(use_cross_encoder)) {
      E_sep_shape <- reticulate::tuple(ModelDims)
      E_sep <- p2d(
        name = "E_sep",
        sample_fxn = function() {
          strenv$numpyro$sample(
            "E_sep",
            strenv$numpyro$distributions$Normal(0., tau_context),
            sample_shape = E_sep_shape
          )
        },
        init_fxn = function() {
          p2d_init_normal("E_sep", tau_context, E_sep_shape)
        }
      )

      E_segment_shape <- reticulate::tuple(ai(2L), ModelDims)
      E_segment <- p2d(
        name = "E_segment",
        sample_fxn = function() {
          strenv$numpyro$sample(
            "E_segment",
            strenv$numpyro$distributions$Normal(0., tau_context),
            sample_shape = E_segment_shape
          )
        },
        init_fxn = function() {
          p2d_init_normal("E_segment", tau_context, E_segment_shape)
        }
      )
    }

    W_resp_x <- NULL
    if (n_resp_covariates > 0L) {
      W_resp_x_shape <- reticulate::tuple(ai(n_resp_covariates), ModelDims)
      W_resp_x <- p2d(
        name = "W_resp_x",
        sample_fxn = function() {
          strenv$numpyro$sample(
            "W_resp_x",
            strenv$numpyro$distributions$Normal(0., resp_cov_sd),
            sample_shape = W_resp_x_shape
          )
        },
        init_fxn = function() {
          p2d_init_normal("W_resp_x", resp_cov_sd, W_resp_x_shape)
        }
      )
    }

    layer_params <- list()
    for (l_ in 1L:ModelDepth) {
      tau_w_prior <- as.numeric(weight_sd_scale * depth_prior_scale)
      tau_w_l <- if (isTRUE(output_only_mode)) {
        tau_w_prior
      } else {
        strenv$numpyro$sample(
          paste0("tau_w_", l_),
          strenv$numpyro$distributions$HalfNormal(tau_w_prior)
        )
      }

      alpha_attn_name <- paste0("alpha_attn_l", l_)
      alpha_attn_l <- p2d(
        name = alpha_attn_name,
        sample_fxn = function() {
          strenv$numpyro$sample(
            alpha_attn_name,
            strenv$numpyro$distributions$HalfNormal(gate_sd_scale)
          )
        },
        init_fxn = function() {
          p2d_init_halfnormal(alpha_attn_name, gate_sd_scale, reticulate::tuple())
        },
        constraint = p2d_constraint_positive
      )

      alpha_ff_name <- paste0("alpha_ff_l", l_)
      alpha_ff_l <- p2d(
        name = alpha_ff_name,
        sample_fxn = function() {
          strenv$numpyro$sample(
            alpha_ff_name,
            strenv$numpyro$distributions$HalfNormal(gate_sd_scale)
          )
        },
        init_fxn = function() {
          p2d_init_halfnormal(alpha_ff_name, gate_sd_scale, reticulate::tuple())
        },
        constraint = p2d_constraint_positive
      )

      RMS_attn_name <- paste0("RMS_attn_l", l_)
      RMS_attn_shape <- reticulate::tuple(ModelDims)
      RMS_attn_l <- p2d(
        name = RMS_attn_name,
        sample_fxn = function() {
          strenv$numpyro$sample(
            RMS_attn_name,
            strenv$numpyro$distributions$LogNormal(0., RMS_scale),
            sample_shape = RMS_attn_shape
          )
        },
        init_fxn = function() {
          p2d_init_lognormal(RMS_attn_name, RMS_scale, RMS_attn_shape)
        },
        constraint = p2d_constraint_positive
      )

      RMS_ff_name <- paste0("RMS_ff_l", l_)
      RMS_ff_shape <- reticulate::tuple(ModelDims)
      RMS_ff_l <- p2d(
        name = RMS_ff_name,
        sample_fxn = function() {
          strenv$numpyro$sample(
            RMS_ff_name,
            strenv$numpyro$distributions$LogNormal(0., RMS_scale),
            sample_shape = RMS_ff_shape
          )
        },
        init_fxn = function() {
          p2d_init_lognormal(RMS_ff_name, RMS_scale, RMS_ff_shape)
        },
        constraint = p2d_constraint_positive
      )

      W_q_name <- paste0("W_q_l", l_)
      W_q_shape <- reticulate::tuple(ModelDims, ModelDims)
      W_q_l <- p2d(
        name = W_q_name,
        sample_fxn = function() {
          sample_loc_scale(W_q_name, tau_w_l, W_q_shape)
        },
        init_fxn = function() {
          p2d_init_normal(W_q_name, tau_w_l, W_q_shape)
        }
      )

      W_k_name <- paste0("W_k_l", l_)
      W_k_shape <- reticulate::tuple(ModelDims, ModelDims)
      W_k_l <- p2d(
        name = W_k_name,
        sample_fxn = function() {
          sample_loc_scale(W_k_name, tau_w_l, W_k_shape)
        },
        init_fxn = function() {
          p2d_init_normal(W_k_name, tau_w_l, W_k_shape)
        }
      )

      W_v_name <- paste0("W_v_l", l_)
      W_v_shape <- reticulate::tuple(ModelDims, ModelDims)
      W_v_l <- p2d(
        name = W_v_name,
        sample_fxn = function() {
          sample_loc_scale(W_v_name, tau_w_l, W_v_shape)
        },
        init_fxn = function() {
          p2d_init_normal(W_v_name, tau_w_l, W_v_shape)
        }
      )

      W_o_name <- paste0("W_o_l", l_)
      W_o_shape <- reticulate::tuple(ModelDims, ModelDims)
      W_o_l <- p2d(
        name = W_o_name,
        sample_fxn = function() {
          sample_loc_scale(W_o_name, tau_w_l, W_o_shape)
        },
        init_fxn = function() {
          p2d_init_normal(W_o_name, tau_w_l, W_o_shape)
        }
      )

      W_ff1_name <- paste0("W_ff1_l", l_)
      W_ff1_shape <- reticulate::tuple(ModelDims, FFDim)
      W_ff1_l <- p2d(
        name = W_ff1_name,
        sample_fxn = function() {
          sample_loc_scale(W_ff1_name, tau_w_l, W_ff1_shape)
        },
        init_fxn = function() {
          p2d_init_normal(W_ff1_name, tau_w_l, W_ff1_shape)
        }
      )

      W_ff2_name <- paste0("W_ff2_l", l_)
      W_ff2_shape <- reticulate::tuple(FFDim, ModelDims)
      W_ff2_l <- p2d(
        name = W_ff2_name,
        sample_fxn = function() {
          sample_loc_scale(W_ff2_name, tau_w_l, W_ff2_shape)
        },
        init_fxn = function() {
          p2d_init_normal(W_ff2_name, tau_w_l, W_ff2_shape)
        }
      )

      layer_params[[paste0("W_q_l", l_)]] <- W_q_l
      layer_params[[paste0("W_k_l", l_)]] <- W_k_l
      layer_params[[paste0("W_v_l", l_)]] <- W_v_l
      layer_params[[paste0("W_o_l", l_)]] <- W_o_l
      layer_params[[paste0("W_ff1_l", l_)]] <- W_ff1_l
      layer_params[[paste0("W_ff2_l", l_)]] <- W_ff2_l
      layer_params[[paste0("RMS_attn_l", l_)]] <- RMS_attn_l
      layer_params[[paste0("RMS_ff_l", l_)]] <- RMS_ff_l
      layer_params[[paste0("alpha_attn_l", l_)]] <- alpha_attn_l
      layer_params[[paste0("alpha_ff_l", l_)]] <- alpha_ff_l
    }

    RMS_final_shape <- reticulate::tuple(ModelDims)
    RMS_final <- p2d(
      name = "RMS_final",
      sample_fxn = function() {
        strenv$numpyro$sample(
          "RMS_final",
          strenv$numpyro$distributions$LogNormal(0., RMS_scale),
          sample_shape = RMS_final_shape
        )
      },
      init_fxn = function() {
        p2d_init_lognormal("RMS_final", RMS_scale, RMS_final_shape)
      },
      constraint = p2d_constraint_positive
    )
    tau_w_out <- strenv$numpyro$sample(
      "tau_w_out",
      strenv$numpyro$distributions$HalfNormal(as.numeric(weight_sd_scale))
    )
    W_out <- sample_loc_scale("W_out", tau_w_out,
                              reticulate::tuple(ModelDims, nOutcomes))
    tau_b <- strenv$numpyro$sample(
      "tau_b",
      strenv$numpyro$distributions$HalfNormal(as.numeric(tau_b_scale))
    )
    b_out <- sample_loc_scale("b_out", tau_b, reticulate::tuple(nOutcomes))

    M_cross <- NULL
    W_cross_out <- NULL
    if (isTRUE(pairwise) && isTRUE(use_cross_term)) {
      # Antisymmetric bilinear term enables opponent-dependent matchups.
      tau_cross <- if (isTRUE(output_only_mode)) {
        as.numeric(cross_weight_sd_scale)
      } else {
        strenv$numpyro$sample(
          "tau_cross",
          strenv$numpyro$distributions$HalfNormal(as.numeric(cross_weight_sd_scale))
        )
      }
      M_cross_shape <- reticulate::tuple(ModelDims, ModelDims)
      M_cross_raw <- p2d(
        name = "M_cross_raw",
        sample_fxn = function() {
          sample_loc_scale("M_cross_raw", tau_cross, M_cross_shape)
        },
        init_fxn = function() {
          p2d_init_normal("M_cross_raw", tau_cross, M_cross_shape)
        }
      )
      M_cross <- 0.5 * (M_cross_raw - strenv$jnp$transpose(M_cross_raw))
      M_cross <- strenv$numpyro$deterministic("M_cross", M_cross)
      W_cross_out <- strenv$numpyro$sample(
        "W_cross_out",
        strenv$numpyro$distributions$Normal(0., 0.25),
        sample_shape = reticulate::tuple(nOutcomes)
      )
    }

    sigma <- NULL
    if (likelihood == "normal") {
      sigma <- strenv$numpyro$sample(
        "sigma",
        strenv$numpyro$distributions$HalfNormal(as.numeric(sigma_prior_scale))
      )
    }

    params_view <- if (isTRUE(pairwise)) {
      list(
        E_feature_id = E_feature_id,
        E_party = E_party,
        E_rel = E_rel,
        E_resp_party = E_resp_party,
        E_stage = E_stage,
        E_choice = E_choice,
        E_sep = E_sep,
        E_segment = E_segment
      )
    } else {
      list(
        E_feature_id = E_feature_id,
        E_party = E_party,
        E_rel = E_rel,
        E_resp_party = E_resp_party,
        E_choice = E_choice
      )
    }
    if (isTRUE(pairwise) && isTRUE(use_matchup_token)) {
      params_view$E_matchup <- E_matchup
    }
    if (n_resp_covariates > 0L) {
      params_view$W_resp_x <- W_resp_x
    }
    for (d_ in 1L:D_local) {
      params_view[[paste0("E_factor_", d_)]] <- E_factor_list[[d_]]
    }
    params_view <- c(params_view, layer_params)
    params_view$RMS_final <- RMS_final
    params_view$W_out <- W_out
    params_view$b_out <- b_out
    if (isTRUE(pairwise) && isTRUE(use_cross_term)) {
      params_view$M_cross <- M_cross
      params_view$W_cross_out <- W_cross_out
    }

    list(
      params_view = params_view,
      E_choice = E_choice,
      W_out = W_out,
      b_out = b_out,
      sigma = sigma,
      M_cross = M_cross,
      W_cross_out = W_cross_out
    )
  }

  BayesianPairTransformerModel <- function(X_left, X_right, party_left, party_right,
                                           resp_party, resp_cov, Y_obs) {
    N_local <- ai(X_left$shape[[1]])
    D_local <- ai(X_left$shape[[2]])

    shared_params <- sample_shared_transformer_params(D_local = D_local, pairwise = TRUE)
    params_view <- shared_params$params_view
    E_choice <- shared_params$E_choice
    W_out <- shared_params$W_out
    b_out <- shared_params$b_out
    sigma <- shared_params$sigma
    M_cross <- shared_params$M_cross
    W_cross_out <- shared_params$W_cross_out

    transformer_model_info <- list(
      model_depth = ModelDepth,
      model_dims = ModelDims,
      n_heads = TransformerHeads,
      head_dim = head_dim
    )
    model_info_local <- list(
      model_dims = ModelDims,
      cand_party_to_resp_idx = cand_party_to_resp_idx_jnp,
      n_party_levels = ai(n_party_levels)
    )

    embed_candidate <- function(X_idx, party_idx, resp_p) {
      neural_build_candidate_tokens_hard(X_idx, party_idx,
                                         model_info = model_info_local,
                                         resp_party_idx = resp_p,
                                         params = params_view)
    }

    add_segment_embedding <- function(tokens, segment_idx) {
      neural_add_segment_embedding(tokens, segment_idx,
                                   model_info = model_info_local,
                                   params = params_view)
    }

    run_transformer <- function(tokens) {
      neural_run_transformer(tokens,
                             model_info = transformer_model_info,
                             params = params_view)
    }

    compute_matchup_idx <- function(pl, pr) {
      neural_matchup_index(pl, pr, model_info_local)
    }

    build_context_tokens <- function(stage_idx, resp_p, resp_c, matchup_idx = NULL) {
      neural_build_context_tokens_batch(model_info = model_info_local,
                                        resp_party_idx = resp_p,
                                        stage_idx = stage_idx,
                                        matchup_idx = matchup_idx,
                                        resp_cov = resp_c,
                                        params = params_view)
    }

    build_sep_token <- function(N_batch) {
      neural_build_sep_token(model_info_local,
                             n_batch = N_batch,
                             params = params_view)
    }

    encode_pair_cross <- function(Xl, Xr, pl, pr, resp_p, resp_c, stage_idx, matchup_idx = NULL) {
      N_batch <- ai(Xl$shape[[1]])
      choice_tok <- strenv$jnp$reshape(E_choice, list(1L, 1L, ModelDims))
      choice_tok <- choice_tok * strenv$jnp$ones(list(N_batch, 1L, 1L))
      ctx_tokens <- build_context_tokens(stage_idx, resp_p, resp_c, matchup_idx)
      left_tokens <- add_segment_embedding(embed_candidate(Xl, pl, resp_p), 0L)
      right_tokens <- add_segment_embedding(embed_candidate(Xr, pr, resp_p), 1L)
      sep_tok <- build_sep_token(N_batch)
      tokens <- strenv$jnp$concatenate(list(choice_tok, ctx_tokens, sep_tok,
                                            left_tokens, sep_tok, right_tokens),
                                       axis = 1L)
      tokens <- run_transformer(tokens)
      cls_out <- strenv$jnp$take(tokens, strenv$jnp$arange(1L), axis = 1L)
      cls_out <- strenv$jnp$squeeze(cls_out, axis = 1L)
      strenv$jnp$einsum("nm,mo->no", cls_out, W_out) + b_out
    }

    encode_candidate <- function(Xa, pa, resp_p, resp_c, stage_idx, matchup_idx = NULL) {
      N_batch <- ai(Xa$shape[[1]])
      choice_tok <- strenv$jnp$reshape(E_choice, list(1L, 1L, ModelDims))
      choice_tok <- choice_tok * strenv$jnp$ones(list(N_batch, 1L, 1L))
      ctx_tokens <- build_context_tokens(stage_idx, resp_p, resp_c, matchup_idx)
      cand_tokens <- embed_candidate(Xa, pa, resp_p)
      tokens <- strenv$jnp$concatenate(list(choice_tok, ctx_tokens, cand_tokens), axis = 1L)
      tokens <- run_transformer(tokens)
      choice_out <- strenv$jnp$take(tokens, strenv$jnp$arange(1L), axis = 1L)
      strenv$jnp$squeeze(choice_out, axis = 1L)
    }

    do_forward_and_lik_ <- function(Xl, Xr, pl, pr, resp_p, resp_c, Yb) {
      stage_idx <- neural_stage_index(pl, pr, model_info_local)
      matchup_idx <- NULL
      if (isTRUE(use_matchup_token)) {
        matchup_idx <- compute_matchup_idx(pl, pr)
      }
      if (isTRUE(use_cross_encoder)) {
        logits <- encode_pair_cross(Xl, Xr, pl, pr, resp_p, resp_c, stage_idx, matchup_idx)
      } else {
        phi_l <- encode_candidate(Xl, pl, resp_p, resp_c, stage_idx, matchup_idx)
        phi_r <- encode_candidate(Xr, pr, resp_p, resp_c, stage_idx, matchup_idx)
        u_l <- strenv$jnp$einsum("nm,mo->no", phi_l, W_out) + b_out
        u_r <- strenv$jnp$einsum("nm,mo->no", phi_r, W_out) + b_out
        logits <- u_l - u_r
        if (isTRUE(use_cross_term)) {
          cross_term <- strenv$jnp$einsum("nm,mp,np->n", phi_l, M_cross, phi_r)
          cross_term <- strenv$jnp$reshape(cross_term, list(-1L, 1L))
          cross_out <- strenv$jnp$reshape(W_cross_out, list(1L, -1L))
          logits <- logits + cross_term * cross_out
        }
      }

      if (likelihood == "bernoulli") {
        logits_vec <- strenv$jnp$squeeze(logits, axis = 1L)
        strenv$numpyro$sample("obs",
                              strenv$numpyro$distributions$Bernoulli(logits = logits_vec),
                              obs = Yb)
      }
      if (likelihood == "categorical") {
        strenv$numpyro$sample("obs",
                              strenv$numpyro$distributions$Categorical(logits = logits),
                              obs = Yb)
      }
      if (likelihood == "normal") {
        mu <- strenv$jnp$squeeze(logits, axis = 1L)
        strenv$numpyro$sample("obs",
                              strenv$numpyro$distributions$Normal(mu, sigma),
                              obs = Yb)
      }
    }

    local_lik <- function() {
      if (isTRUE(subsample_method %in% c("batch", "batch_vi"))) {
        with(strenv$numpyro$plate("data", size = N_local,
                                  subsample_size = ai(mcmc_control$batch_size),
                                  dim = -1L) %as% "idx", {
                                    Xl_b <- strenv$jnp$take(X_left, idx, axis = 0L)
                                    Xr_b <- strenv$jnp$take(X_right, idx, axis = 0L)
                                    pl_b <- strenv$jnp$take(party_left, idx, axis = 0L)
                                    pr_b <- strenv$jnp$take(party_right, idx, axis = 0L)
                                    resp_p_b <- strenv$jnp$take(resp_party, idx, axis = 0L)
                                    resp_c_b <- strenv$jnp$take(resp_cov, idx, axis = 0L)
                                    Yb <- strenv$jnp$take(Y_obs, idx, axis = 0L)
                                    do_forward_and_lik_(Xl_b, Xr_b, pl_b, pr_b, resp_p_b, resp_c_b, Yb)
                                  })
      } else {
        with(strenv$numpyro$plate("data", size = N_local, dim = -1L), {
          do_forward_and_lik_(X_left, X_right, party_left, party_right,
                              resp_party, resp_cov, Y_obs)
        })
      }
    }

    local_lik()
  }

  BayesianSingleTransformerModel <- function(X, party, resp_party, resp_cov, Y_obs) {
    N_local <- ai(X$shape[[1]])
    D_local <- ai(X$shape[[2]])

    shared_params <- sample_shared_transformer_params(D_local = D_local, pairwise = FALSE)
    params_view <- shared_params$params_view
    E_choice <- shared_params$E_choice
    W_out <- shared_params$W_out
    b_out <- shared_params$b_out
    sigma <- shared_params$sigma

    transformer_model_info <- list(
      model_depth = ModelDepth,
      model_dims = ModelDims,
      n_heads = TransformerHeads,
      head_dim = head_dim
    )
    model_info_local <- list(
      model_dims = ModelDims,
      cand_party_to_resp_idx = cand_party_to_resp_idx_jnp,
      n_party_levels = ai(n_party_levels)
    )

    embed_candidate <- function(X_idx, party_idx, resp_p) {
      neural_build_candidate_tokens_hard(X_idx, party_idx,
                                         model_info = model_info_local,
                                         resp_party_idx = resp_p,
                                         params = params_view)
    }

    run_transformer <- function(tokens) {
      neural_run_transformer(tokens,
                             model_info = transformer_model_info,
                             params = params_view)
    }

    do_forward_and_lik_ <- function(Xb, pb, resp_p, resp_c, Yb) {
      N_batch <- ai(Xb$shape[[1]])
      choice_tok <- strenv$jnp$reshape(E_choice, list(1L, 1L, ModelDims))
      choice_tok <- choice_tok * strenv$jnp$ones(list(N_batch, 1L, 1L))
      ctx_tokens <- neural_build_context_tokens_batch(model_info = model_info_local,
                                                      resp_party_idx = resp_p,
                                                      resp_cov = resp_c,
                                                      params = params_view)
      cand_tokens <- embed_candidate(Xb, pb, resp_p)
      token_parts <- list(choice_tok)
      if (!is.null(ctx_tokens)) {
        token_parts <- c(token_parts, list(ctx_tokens))
      }
      token_parts <- c(token_parts, list(cand_tokens))
      tokens <- strenv$jnp$concatenate(token_parts, axis = 1L)
      tokens <- run_transformer(tokens)
      choice_out <- strenv$jnp$take(tokens, strenv$jnp$arange(1L), axis = 1L)
      choice_out <- strenv$jnp$squeeze(choice_out, axis = 1L)
      logits <- strenv$jnp$einsum("nm,mo->no", choice_out, W_out) + b_out

      if (likelihood == "bernoulli") {
        logits_vec <- strenv$jnp$squeeze(logits, axis = 1L)
        strenv$numpyro$sample("obs",
                              strenv$numpyro$distributions$Bernoulli(logits = logits_vec),
                              obs = Yb)
      }
      if (likelihood == "categorical") {
        strenv$numpyro$sample("obs",
                              strenv$numpyro$distributions$Categorical(logits = logits),
                              obs = Yb)
      }
      if (likelihood == "normal") {
        mu <- strenv$jnp$squeeze(logits, axis = 1L)
        strenv$numpyro$sample("obs",
                              strenv$numpyro$distributions$Normal(mu, sigma),
                              obs = Yb)
      }
    }

    local_lik <- function() {
      if (isTRUE(subsample_method %in% c("batch", "batch_vi"))) {
        with(strenv$numpyro$plate("data", size = N_local,
                                  subsample_size = ai(mcmc_control$batch_size),
                                  dim = -1L) %as% "idx", {
                                    Xb <- strenv$jnp$take(X, idx, axis = 0L)
                                    pb <- strenv$jnp$take(party, idx, axis = 0L)
                                    resp_p_b <- strenv$jnp$take(resp_party, idx, axis = 0L)
                                    resp_c_b <- strenv$jnp$take(resp_cov, idx, axis = 0L)
                                    Yb <- strenv$jnp$take(Y_obs, idx, axis = 0L)
                                    do_forward_and_lik_(Xb, pb, resp_p_b, resp_c_b, Yb)
                                  })
      } else {
        with(strenv$numpyro$plate("data", size = N_local, dim = -1L), {
          do_forward_and_lik_(X, party, resp_party, resp_cov, Y_obs)
        })
      }
    }

    local_lik()
  }

  if (likelihood == "categorical") {
    y_fac <- ai(as.factor(Y_use)) - 1L
    Y_jnp <- strenv$jnp$array(y_fac)$astype(strenv$jnp$int32)
  } else {
    Y_jnp <- strenv$jnp$array(as.numeric(Y_use))$astype(ddtype_)
  }
  resp_party_jnp <- strenv$jnp$array(as.integer(resp_party_use))$astype(strenv$jnp$int32)
  if (n_resp_covariates > 0L) {
    resp_cov_jnp <- strenv$jnp$array(as.matrix(X_use))$astype(ddtype_)
  } else {
    resp_cov_jnp <- strenv$jnp$zeros(list(ai(length(Y_use)), ai(0L)), dtype = ddtype_)
  }

  if (pairwise_mode) {
    X_left_jnp <- strenv$jnp$array(to_index_matrix(X_left))$astype(strenv$jnp$int32)
    X_right_jnp <- strenv$jnp$array(to_index_matrix(X_right))$astype(strenv$jnp$int32)
    party_left_jnp <- strenv$jnp$array(as.integer(party_left))$astype(strenv$jnp$int32)
    party_right_jnp <- strenv$jnp$array(as.integer(party_right))$astype(strenv$jnp$int32)
  } else {
    X_single_jnp <- strenv$jnp$array(to_index_matrix(X_single))$astype(strenv$jnp$int32)
    party_single_jnp <- strenv$jnp$array(as.integer(party_single))$astype(strenv$jnp$int32)
  }

  model_fn_base <- if (pairwise_mode) BayesianPairTransformerModel else BayesianSingleTransformerModel
  model_fn <- model_fn_base
  locscale_reparam <- NULL
  if (!is.null(strenv$numpyro$infer) &&
      reticulate::py_has_attr(strenv$numpyro$infer, "reparam")) {
    reparam_mod <- strenv$numpyro$infer$reparam
    if (reticulate::py_has_attr(reparam_mod, "LocScaleReparam")) {
      locscale_reparam <- reparam_mod$LocScaleReparam
    }
  }
  if (is.null(locscale_reparam)) {
    locscale_reparam <- tryCatch(
      reticulate::import("numpyro.infer.reparam", delay_load = TRUE)$LocScaleReparam,
      error = function(e) NULL
    )
  }
  if (!is.null(locscale_reparam) &&
      reticulate::py_has_attr(strenv$numpyro, "handlers")) {
    reparam_config <- list()
    for (l_ in 1L:ModelDepth) {
      for (base in c("W_q_l", "W_k_l", "W_v_l", "W_o_l", "W_ff1_l", "W_ff2_l")) {
        site <- paste0(base, l_)
        reparam_config[[site]] <- locscale_reparam(centered = 0)
      }
    }
    reparam_config[["W_out"]] <- locscale_reparam(centered = 0)
    reparam_config[["b_out"]] <- locscale_reparam(centered = 0)
    if (isTRUE(use_cross_term)) {
      reparam_config[["M_cross_raw"]] <- locscale_reparam(centered = 0)
    }
    model_fn <- tryCatch(
      strenv$numpyro$handlers$reparam(fn = model_fn_base, config = reparam_config),
      error = function(e) NULL
    )
    if (is.null(model_fn)) {
      model_fn <- model_fn_base
      manual_noncentered_loc_scale <- TRUE
    } else {
      manual_noncentered_loc_scale <- FALSE
    }
  } else {
    manual_noncentered_loc_scale <- TRUE
  }

  t0_ <- Sys.time()
  output_only_mode <- identical(tolower(as.character(uncertainty_scope)), "output")
  use_svi <- isTRUE(output_only_mode) || identical(subsample_method, "batch_vi")
  SVIParams <- NULL
  svi_loss_curve <- NULL
  if (isTRUE(use_svi)) {
    if (isTRUE(output_only_mode)) {
      message("Enlisting SVI with autoguide for output-only uncertainty...")
    } else {
      message("Enlisting SVI with autoguide for minibatched likelihood...")
    }
    if (!is.null(strenv$numpyro) && reticulate::py_has_attr(strenv$numpyro, "clear_param_store")) {
      tryCatch(strenv$numpyro$clear_param_store(), error = function(e) NULL)
    }
    guide_name <- if (!is.null(mcmc_control$vi_guide)) {
      tolower(as.character(mcmc_control$vi_guide))
    } else {
      "auto_diagonal"
    }
    if (length(guide_name) != 1L || is.na(guide_name) || !nzchar(guide_name)) {
      guide_name <- "auto_diagonal"
    }
    guide <- switch(guide_name,
                    auto_delta = strenv$numpyro$infer$autoguide$AutoDelta(model_fn),
                    auto_normal = strenv$numpyro$infer$autoguide$AutoNormal(model_fn),
                    auto_diagonal = strenv$numpyro$infer$autoguide$AutoDiagonalNormal(model_fn),
                    stop(sprintf("Unknown vi_guide '%s' for SVI.", guide_name), call. = FALSE))
    n_particles <- ai(mcmc_control$svi_num_particles)
    if (length(n_particles) != 1L || is.na(n_particles) || n_particles < 1L) {
      n_particles <- 1L
    }
    optimizer_tag <- if (!is.null(mcmc_control$optimizer)) {
      tolower(as.character(mcmc_control$optimizer))
    } else {
      "adam"
    }
    if (length(optimizer_tag) != 1L || is.na(optimizer_tag) || !nzchar(optimizer_tag)) {
      optimizer_tag <- "adam"
    }
    if (!optimizer_tag %in% c("adam", "adamw", "adabelief")) {
      stop(
        sprintf("Unknown optimizer '%s' for SVI.", optimizer_tag),
        call. = FALSE
      )
    }
    svi_lr <- as.numeric(mcmc_control$svi_lr)
    if (length(svi_lr) != 1L || is.na(svi_lr) || !is.finite(svi_lr) || svi_lr <= 0) {
      svi_lr <- 0.01
    }
    schedule_tag <- if (!is.null(mcmc_control$svi_lr_schedule)) {
      tolower(as.character(mcmc_control$svi_lr_schedule))
    } else {
      "warmup_cosine"
    }
    if (length(schedule_tag) != 1L || is.na(schedule_tag) || !nzchar(schedule_tag)) {
      schedule_tag <- "warmup_cosine"
    }
    if (!schedule_tag %in% c("none", "constant", "cosine", "warmup_cosine")) {
      stop(
        sprintf("Unknown svi_lr_schedule '%s'.", schedule_tag),
        call. = FALSE
      )
    }
    svi_steps_input <- mcmc_control$svi_steps
    svi_steps <- NULL
    if (is.character(svi_steps_input)) {
      steps_tag <- tolower(as.character(svi_steps_input))
      if (length(steps_tag) == 1L && !is.na(steps_tag) && nzchar(steps_tag) &&
          identical(steps_tag, "optimal")) {
        n_obs_svi <- length(Y_use)
        pairwise_scaling <- pairwise_mode
        if (isTRUE(diff) && !is.null(pair_id_) && length(pair_id_) > 0L) {
          pair_id_use <- pair_id_
          pair_id_use <- pair_id_use[!is.na(pair_id_use)]
          if (length(pair_id_use) > 0L) {
            n_obs_svi <- length(unique(pair_id_use))
            pairwise_scaling <- TRUE
          }
        }
        svi_steps <- neural_optimal_svi_steps(
          n_obs = n_obs_svi,
          n_factors = length(factor_levels_int),
          factor_levels = factor_levels_int,
          model_dims = ModelDims,
          model_depth = ModelDepth,
          n_party_levels = n_party_levels,
          n_resp_party_levels = n_resp_party_levels,
          n_resp_covariates = n_resp_covariates,
          n_outcomes = nOutcomes,
          pairwise_mode = pairwise_scaling,
          use_matchup_token = use_matchup_token,
          use_cross_encoder = use_cross_encoder,
          use_cross_term = use_cross_term,
          batch_size = mcmc_control$batch_size,
          subsample_method = subsample_method
        )
        mcmc_control$svi_steps <- svi_steps
        message(sprintf("Using svi_steps='optimal' => %d steps.", svi_steps))
      }
    }
    if (is.null(svi_steps)) {
      svi_steps <- as.integer(svi_steps_input)
      if (length(svi_steps) != 1L || is.na(svi_steps) || svi_steps < 1L) {
        svi_steps <- 1L
      }
    }
    warmup_frac <- if (!is.null(mcmc_control$svi_lr_warmup_frac)) {
      as.numeric(mcmc_control$svi_lr_warmup_frac)
    } else {
      0.1
    }
    if (length(warmup_frac) != 1L || is.na(warmup_frac) || !is.finite(warmup_frac)) {
      warmup_frac <- 0.1
    }
    warmup_frac <- max(0, min(warmup_frac, 0.9))
    decay_steps <- max(2L, svi_steps)
    warmup_steps <- if (schedule_tag == "warmup_cosine") {
      max(1L, min(as.integer(round(svi_steps * warmup_frac)), decay_steps - 1L))
    } else {
      0L
    }
    end_factor <- if (!is.null(mcmc_control$svi_lr_end_factor)) {
      as.numeric(mcmc_control$svi_lr_end_factor)
    } else {
      0.01
    }
    if (length(end_factor) != 1L || is.na(end_factor) || !is.finite(end_factor)) {
      end_factor <- 0.01
    }
    end_factor <- max(0, min(end_factor, 1))
    lr_schedule <- if (schedule_tag == "warmup_cosine") {
      strenv$optax$warmup_cosine_decay_schedule(
        init_value = svi_lr * end_factor,
        peak_value = svi_lr,
        warmup_steps = warmup_steps,
        decay_steps = decay_steps,
        end_value = svi_lr * end_factor
      )
    } else if (schedule_tag == "cosine") {
      strenv$optax$cosine_decay_schedule(
        init_value = svi_lr,
        decay_steps = decay_steps,
        alpha = end_factor
      )
    } else {
      svi_lr
    }
    svi_optim <- if (optimizer_tag == "adam") {
      strenv$numpyro$optim$Adam(lr_schedule)
    } else if (optimizer_tag == "adamw") {
      if (reticulate::py_has_attr(strenv$numpyro$optim, "AdamW")) {
        strenv$numpyro$optim$AdamW(lr_schedule)
      } else if (reticulate::py_has_attr(strenv$optax, "adamw")) {
        optax_optim <- strenv$optax$adamw(learning_rate = lr_schedule)
        if (reticulate::py_has_attr(strenv$numpyro$optim, "optax_to_numpyro")) {
          strenv$numpyro$optim$optax_to_numpyro(optax_optim)
        } else {
          optax_optim
        }
      } else {
        stop(
          "optimizer='adamw' requested, but neither numpyro.optim.AdamW nor optax.adamw is available.",
          call. = FALSE
        )
      }
    } else {
      optax_optim <- strenv$optax$adabelief(learning_rate = lr_schedule)
      if (reticulate::py_has_attr(strenv$numpyro$optim, "optax_to_numpyro")) {
        strenv$numpyro$optim$optax_to_numpyro(optax_optim)
      } else {
        optax_optim
      }
    }
    svi <- strenv$numpyro$infer$SVI(
      model = model_fn,
      guide = guide,
      optim = svi_optim,
      loss = strenv$numpyro$infer$Trace_ELBO(
        num_particles = n_particles
      )
    )
    rng_key <- strenv$jax$random$PRNGKey(ai(runif(1, 0, 10000)))
    if (pairwise_mode) {
      svi_result <- svi$run(rng_key,
                            ai(svi_steps),
                            X_left = X_left_jnp,
                            X_right = X_right_jnp,
                            party_left = party_left_jnp,
                            party_right = party_right_jnp,
                            resp_party = resp_party_jnp,
                            resp_cov = resp_cov_jnp,
                            Y_obs = Y_jnp)
    } else {
      svi_result <- svi$run(rng_key,
                            ai(svi_steps),
                            X = X_single_jnp,
                            party = party_single_jnp,
                            resp_party = resp_party_jnp,
                            resp_cov = resp_cov_jnp,
                            Y_obs = Y_jnp)
    }
    svi_loss_curve <- tryCatch({
      if (reticulate::py_has_attr(svi_result, "losses")) {
        as.numeric(reticulate::py_to_r(svi_result$losses))
      } else if (!is.null(svi_result$losses)) {
        as.numeric(reticulate::py_to_r(svi_result$losses))
      } else {
        NULL
      }
    }, error = function(e) NULL)
    if (!is.null(svi_loss_curve) && length(svi_loss_curve) > 0L &&
        identical(subsample_method, "batch_vi")) {
      svi_loss_curve <- as.numeric(svi_loss_curve)
      svi_loss_curve[!is.finite(svi_loss_curve)] <- NA_real_
      try(suppressWarnings(plot(svi_loss_curve,
                                type = "l",
                                main = "SVI ELBO loss",
                                xlab = "Iteration",
                                ylab = "ELBO loss")), TRUE)
      finite_idx <- is.finite(svi_loss_curve)
      if (sum(finite_idx, na.rm = TRUE) >= 2L) {
        try(points(lowess(svi_loss_curve[finite_idx]),
                   type = "l",
                   lwd = 2,
                   col = "red"), TRUE)
      }
    }
    svi_state <- if (!is.null(svi_result$state)) {
      svi_result$state
    } else if (length(svi_result) > 0L) {
      svi_result[[1]]
    } else {
      svi_result
    }
    params <- svi$get_params(svi_state)
    SVIParams <- params
    n_draws <- ai(mcmc_control$svi_num_draws)
    if (length(n_draws) != 1L || is.na(n_draws) || !is.finite(n_draws) || n_draws < 1L) {
      n_draws <- 1L
    }
    sample_key <- strenv$jax$random$PRNGKey(ai(runif(1, 0, 10000)))
    posterior_samples <- guide$sample_posterior(
      sample_key,
      params,
      sample_shape = reticulate::tuple(ai(n_draws))
    )
    PosteriorDraws <- lapply(posterior_samples, function(x) {
      strenv$jnp$expand_dims(x, 0L)
    })
    names(PosteriorDraws) <- names(posterior_samples)
    message(sprintf("\n SVI Runtime: %.3f min",
                    as.numeric(difftime(Sys.time(), t0_, units = "secs"))/60))
  } else {
    strenv$numpyro$set_host_device_count(mcmc_control$n_chains)

    if (identical(subsample_method, "batch")) {
      message("Enlisting HMCECS kernels for subsampled likelihood...")
      kernel <- strenv$numpyro$infer$HMCECS(
        strenv$numpyro$infer$NUTS(model_fn),
        num_blocks = if (!is.null(mcmc_control$num_blocks)) ai(mcmc_control$num_blocks) else ai(4L)
      )
    } else {
      message("Enlisting NUTS kernels for full-data likelihood...")
      kernel <- strenv$numpyro$infer$NUTS(
        model_fn,
        max_tree_depth = ai(8L),
        target_accept_prob = 0.85
      )
    }

    sampler <- strenv$numpyro$infer$MCMC(
      sampler = kernel,
      num_warmup = mcmc_control$n_samples_warmup,
      num_samples = mcmc_control$n_samples_mcmc,
      thinning   = mcmc_control$n_thin_by,
      chain_method = ifelse(!is.null(mcmc_control$chain_method), yes = mcmc_control$chain_method, no = "parallel"),
      num_chains = mcmc_control$n_chains,
      jit_model_args = TRUE,
      progress_bar = TRUE
    )

    if (pairwise_mode) {
      sampler$run(strenv$jax$random$PRNGKey(ai(runif(1, 0, 10000))),
                  X_left = X_left_jnp,
                  X_right = X_right_jnp,
                  party_left = party_left_jnp,
                  party_right = party_right_jnp,
                  resp_party = resp_party_jnp,
                  resp_cov = resp_cov_jnp,
                  Y_obs = Y_jnp)
    } else {
      sampler$run(strenv$jax$random$PRNGKey(ai(runif(1, 0, 10000))),
                  X = X_single_jnp,
                  party = party_single_jnp,
                  resp_party = resp_party_jnp,
                  resp_cov = resp_cov_jnp,
                  Y_obs = Y_jnp)
    }
    PosteriorDraws <- sampler$get_samples(group_by_chain = TRUE)
    message(sprintf("\n MCMC Runtime: %.3f min",
                    as.numeric(difftime(Sys.time(), t0_, units = "secs"))/60))
  }

  mean_param <- function(x) { strenv$jnp$mean(x, 0L:1L) }
  get_centered_factor_draws <- function(name) {
    draws <- PosteriorDraws[[name]]
    if (!is.null(draws)) {
      return(draws)
    }
    raw_name <- paste0(name, "_raw")
    raw_draws <- PosteriorDraws[[raw_name]]
    if (is.null(raw_draws)) {
      return(NULL)
    }
    d_idx <- suppressWarnings(as.integer(sub("E_factor_", "", name)))
    if (is.na(d_idx) || d_idx < 1L || d_idx > length(factor_levels_int)) {
      return(raw_draws - strenv$jnp$mean(raw_draws, axis = 2L, keepdims = TRUE))
    }
    n_real <- ai(factor_levels_int[d_idx])
    n_levels_raw <- tryCatch(
      as.integer(reticulate::py_to_r(raw_draws$shape[[3]])),
      error = function(e) NA_integer_
    )
    if (is.na(n_levels_raw) || n_levels_raw <= n_real) {
      return(raw_draws - strenv$jnp$mean(raw_draws, axis = 2L, keepdims = TRUE))
    }
    real_idx <- strenv$jnp$arange(n_real)
    raw_real <- strenv$jnp$take(raw_draws, real_idx, axis = 2L)
    mean_real <- strenv$jnp$mean(raw_real, axis = 2L, keepdims = TRUE)
    centered_real <- raw_real - mean_real
    missing_draw <- strenv$jnp$take(raw_draws, ai(n_real), axis = 2L)
    missing_draw <- strenv$jnp$expand_dims(missing_draw, axis = 2L)
    strenv$jnp$concatenate(list(centered_real, missing_draw), axis = 2L)
  }
  get_loc_scale_draws <- function(name, scale_name) {
    draws <- PosteriorDraws[[name]]
    if (!is.null(draws)) {
      return(draws)
    }
    base_names <- c(paste0(name, "_decentered"),
                    paste0(name, "_base"),
                    paste0(name, "_z"))
    base_draws <- NULL
    for (base_name in base_names) {
      if (!is.null(PosteriorDraws[[base_name]])) {
        base_draws <- PosteriorDraws[[base_name]]
        break
      }
    }
    if (is.null(base_draws)) {
      return(NULL)
    }
    scale_draws <- PosteriorDraws[[scale_name]]
    if (is.null(scale_draws)) {
      return(NULL)
    }
    scale_shape <- tryCatch(
      as.integer(reticulate::py_to_r(scale_draws$shape)),
      error = function(e) NULL
    )
    base_shape <- tryCatch(
      as.integer(reticulate::py_to_r(base_draws$shape)),
      error = function(e) NULL
    )
    if (is.null(scale_shape) || is.null(base_shape)) {
      return(scale_draws * base_draws)
    }
    extra_dims <- length(base_shape) - length(scale_shape)
    if (extra_dims > 0L) {
      reshape_dims <- c(scale_shape, rep(1L, extra_dims))
      scale_draws <- strenv$jnp$reshape(scale_draws, as.list(reshape_dims))
    }
    scale_draws * base_draws
  }
  get_cross_draws <- function() {
    draws <- PosteriorDraws$M_cross
    if (!is.null(draws)) {
      return(draws)
    }
    raw_draws <- PosteriorDraws$M_cross_raw
    if (is.null(raw_draws)) {
      raw_draws <- get_loc_scale_draws("M_cross_raw", "tau_cross")
    }
    if (is.null(raw_draws)) {
      return(NULL)
    }
    trans_axes <- list(0L, 1L, 3L, 2L)
    0.5 * (raw_draws - strenv$jnp$transpose(raw_draws, trans_axes))
  }
  get_param_draws <- function(name) {
    if (startsWith(name, "E_factor_")) {
      return(get_centered_factor_draws(name))
    }
    if (identical(name, "M_cross")) {
      return(get_cross_draws())
    }
    if (identical(name, "W_out")) {
      return(get_loc_scale_draws("W_out", "tau_w_out"))
    }
    if (identical(name, "b_out")) {
      return(get_loc_scale_draws("b_out", "tau_b"))
    }
    if (grepl("^W_(q|k|v|o)_l\\d+$", name) ||
        grepl("^W_ff(1|2)_l\\d+$", name)) {
      layer_id <- sub(".*_l", "", name)
      tau_name <- paste0("tau_w_", layer_id)
      return(get_loc_scale_draws(name, tau_name))
    }
    PosteriorDraws[[name]]
  }

  p2d_output_only <- isTRUE(output_only_mode)
  get_svi_param <- function(name) {
    if (is.null(SVIParams)) {
      return(NULL)
    }
    tryCatch(SVIParams[[name]], error = function(e) NULL)
  }
  get_site_mean_or_param <- function(name) {
    draws <- PosteriorDraws[[name]]
    if (!is.null(draws)) {
      return(mean_param(draws))
    }
    get_svi_param(name)
  }

  ParamsMean <- list()
  ParamsMean$E_party <- get_site_mean_or_param("E_party")
  ParamsMean$E_resp_party <- get_site_mean_or_param("E_resp_party")
  ParamsMean$E_choice <- get_site_mean_or_param("E_choice")
  if (is.null(ParamsMean$E_party) || is.null(ParamsMean$E_resp_party) || is.null(ParamsMean$E_choice)) {
    stop("Neural model is missing required embedding estimates.", call. = FALSE)
  }

  maybe_site <- function(name, assign_as = name) {
    value <- get_site_mean_or_param(name)
    if (!is.null(value)) {
      ParamsMean[[assign_as]] <<- value
    }
    invisible(value)
  }

  maybe_site("E_sep")
  maybe_site("E_segment")
  maybe_site("E_feature_id")
  maybe_site("E_rel")
  maybe_site("E_stage")
  maybe_site("E_matchup")

  W_out_draws <- get_loc_scale_draws("W_out", "tau_w_out")
  if (!is.null(W_out_draws)) {
    ParamsMean$W_out <- mean_param(W_out_draws)
  }
  b_out_draws <- get_loc_scale_draws("b_out", "tau_b")
  if (!is.null(b_out_draws)) {
    ParamsMean$b_out <- mean_param(b_out_draws)
  }

  cross_draws <- get_cross_draws()
  if (!is.null(cross_draws)) {
    ParamsMean$M_cross <- mean_param(cross_draws)
  } else if (isTRUE(p2d_output_only) && isTRUE(pairwise_mode) && isTRUE(use_cross_term)) {
    M_cross_raw <- get_svi_param("M_cross_raw")
    if (!is.null(M_cross_raw)) {
      ParamsMean$M_cross <- 0.5 * (M_cross_raw - strenv$jnp$transpose(M_cross_raw))
    }
  }

  if (!is.null(PosteriorDraws$W_cross_out)) {
    ParamsMean$W_cross_out <- mean_param(PosteriorDraws$W_cross_out)
  }
  if (likelihood == "normal") {
    ParamsMean$sigma <- mean_param(PosteriorDraws$sigma)
  }

  if (n_resp_covariates > 0L) {
    maybe_site("W_resp_x")
  }

  for (d_ in seq_along(factor_levels_int)) {
    name <- paste0("E_factor_", d_)
    draws <- get_centered_factor_draws(name)
    if (!is.null(draws)) {
      ParamsMean[[name]] <- mean_param(draws)
    } else if (isTRUE(p2d_output_only)) {
      raw_name <- paste0(name, "_raw")
      raw_val <- get_svi_param(raw_name)
      if (!is.null(raw_val)) {
        ParamsMean[[name]] <- center_factor_embeddings(raw_val, factor_levels_int[d_])
      }
    }
  }

  for (l_ in 1L:ModelDepth) {
    alpha_attn_name <- paste0("alpha_attn_l", l_)
    alpha_ff_name <- paste0("alpha_ff_l", l_)
    maybe_site(alpha_attn_name)
    maybe_site(alpha_ff_name)

    maybe_site(paste0("RMS_attn_l", l_))
    maybe_site(paste0("RMS_ff_l", l_))

    for (base in c("W_q_l", "W_k_l", "W_v_l", "W_o_l", "W_ff1_l", "W_ff2_l")) {
      name <- paste0(base, l_)
      tau_name <- paste0("tau_w_", l_)
      draws <- get_loc_scale_draws(name, tau_name)
      if (!is.null(draws)) {
        ParamsMean[[name]] <- mean_param(draws)
      } else if (isTRUE(p2d_output_only)) {
        value <- get_svi_param(name)
        if (!is.null(value)) {
          ParamsMean[[name]] <- value
        }
      }
    }
  }
  maybe_site("RMS_final")

  TransformerPredict_pair <- function(params, Xl_new, Xr_new, pl_new, pr_new,
                                      resp_party_new = NULL, resp_cov_new = NULL,
                                      return_logits = FALSE) {
    Xl <- strenv$jnp$array(to_index_matrix(Xl_new))$astype(strenv$jnp$int32)
    Xr <- strenv$jnp$array(to_index_matrix(Xr_new))$astype(strenv$jnp$int32)
    pl <- strenv$jnp$array(as.integer(pl_new))$astype(strenv$jnp$int32)
    pr <- strenv$jnp$array(as.integer(pr_new))$astype(strenv$jnp$int32)
    if (is.null(resp_party_new)) {
      resp_party_new <- rep(0L, nrow(Xl_new))
    }
    resp_p <- strenv$jnp$array(as.integer(resp_party_new))$astype(strenv$jnp$int32)
    if (is.null(resp_cov_new)) {
      resp_cov_new <- if (!is.null(resp_cov_mean)) {
        matrix(rep(resp_cov_mean, each = nrow(Xl_new)), nrow = nrow(Xl_new))
      } else {
        matrix(0, nrow = nrow(Xl_new), ncol = 0L)
      }
    }
    resp_c <- strenv$jnp$array(as.matrix(resp_cov_new))$astype(ddtype_)

    model_info_local <- list(
      model_dims = ModelDims,
      cand_party_to_resp_idx = cand_party_to_resp_idx_jnp
    )

    embed_candidate <- function(X_idx, party_idx, resp_p) {
      neural_build_candidate_tokens_hard(X_idx, party_idx,
                                         model_info = model_info_local,
                                         resp_party_idx = resp_p,
                                         params = params)
    }

    add_segment_embedding <- function(tokens, segment_idx) {
      neural_add_segment_embedding(tokens, segment_idx,
                                   model_info = model_info_local,
                                   params = params)
    }

    run_transformer <- function(tokens) {
      neural_run_transformer(tokens,
                             model_info = list(model_depth = ModelDepth,
                                               model_dims = ModelDims,
                                               n_heads = TransformerHeads,
                                               head_dim = head_dim),
                             params = params)
    }

    compute_matchup_idx <- function(pl, pr) {
      p_min <- strenv$jnp$minimum(pl, pr)
      p_max <- strenv$jnp$maximum(pl, pr)
      half_term <- strenv$jnp$floor_divide(p_min * (p_min - 1L), ai(2L))
      idx <- p_min * ai(n_party_levels) - half_term + (p_max - p_min)
      strenv$jnp$astype(idx, strenv$jnp$int32)
    }

    build_context_tokens <- function(stage_idx, resp_p, resp_c, matchup_idx = NULL) {
      neural_build_context_tokens_batch(model_info = model_info_local,
                                        resp_party_idx = resp_p,
                                        stage_idx = stage_idx,
                                        matchup_idx = matchup_idx,
                                        resp_cov = resp_c,
                                        params = params)
    }

    build_sep_token <- function(N_batch) {
      neural_build_sep_token(model_info_local,
                             n_batch = N_batch,
                             params = params)
    }

    encode_pair_cross <- function(Xl, Xr, pl, pr, resp_p, resp_c, stage_idx, matchup_idx = NULL) {
      N_batch <- ai(Xl$shape[[1]])
      choice_vec <- if (!is.null(params$E_choice)) {
        params$E_choice
      } else {
        strenv$jnp$zeros(list(ModelDims), dtype = strenv$dtj)
      }
      choice_tok <- strenv$jnp$reshape(choice_vec, list(1L, 1L, ModelDims))
      choice_tok <- choice_tok * strenv$jnp$ones(list(N_batch, 1L, 1L))
      ctx_tokens <- build_context_tokens(stage_idx, resp_p, resp_c, matchup_idx)
      left_tokens <- add_segment_embedding(embed_candidate(Xl, pl, resp_p), 0L)
      right_tokens <- add_segment_embedding(embed_candidate(Xr, pr, resp_p), 1L)
      sep_tok <- build_sep_token(N_batch)
      token_parts <- list(choice_tok)
      if (!is.null(ctx_tokens)) {
        token_parts <- c(token_parts, list(ctx_tokens))
      }
      token_parts <- c(token_parts, list(sep_tok, left_tokens, sep_tok, right_tokens))
      tokens <- strenv$jnp$concatenate(token_parts, axis = 1L)
      tokens <- run_transformer(tokens)
      cls_out <- strenv$jnp$take(tokens, strenv$jnp$arange(1L), axis = 1L)
      cls_out <- strenv$jnp$squeeze(cls_out, axis = 1L)
      b_out <- if (!is.null(params$b_out)) {
        params$b_out
      } else {
        strenv$jnp$zeros(list(ai(params$W_out$shape[[2]])), dtype = strenv$dtj)
      }
      strenv$jnp$einsum("nm,mo->no", cls_out, params$W_out) + b_out
    }

    encode_candidate <- function(Xa, pa, resp_p, resp_c, stage_idx, matchup_idx = NULL) {
      N_batch <- ai(Xa$shape[[1]])
      choice_tok <- strenv$jnp$reshape(params$E_choice, list(1L, 1L, ModelDims))
      choice_tok <- choice_tok * strenv$jnp$ones(list(N_batch, 1L, 1L))
      ctx_tokens <- build_context_tokens(stage_idx, resp_p, resp_c, matchup_idx)
      cand_tokens <- embed_candidate(Xa, pa, resp_p)
      if (is.null(ctx_tokens)) {
        tokens <- strenv$jnp$concatenate(list(choice_tok, cand_tokens), axis = 1L)
      } else {
        tokens <- strenv$jnp$concatenate(list(choice_tok, ctx_tokens, cand_tokens), axis = 1L)
      }
      tokens <- run_transformer(tokens)
      choice_out <- strenv$jnp$take(tokens, strenv$jnp$arange(1L), axis = 1L)
      strenv$jnp$squeeze(choice_out, axis = 1L)
    }

    stage_idx <- neural_stage_index(pl, pr, model_info_local)
    matchup_idx <- NULL
    if (!is.null(params$E_matchup)) {
      matchup_idx <- compute_matchup_idx(pl, pr)
    }
    if (isTRUE(use_cross_encoder)) {
      logits <- encode_pair_cross(Xl, Xr, pl, pr, resp_p, resp_c, stage_idx, matchup_idx)
    } else {
      phi_l <- encode_candidate(Xl, pl, resp_p, resp_c, stage_idx, matchup_idx)
      phi_r <- encode_candidate(Xr, pr, resp_p, resp_c, stage_idx, matchup_idx)
      b_out <- if (!is.null(params$b_out)) {
        params$b_out
      } else {
        strenv$jnp$zeros(list(ai(params$W_out$shape[[2]])), dtype = strenv$dtj)
      }
      u_l <- strenv$jnp$einsum("nm,mo->no", phi_l, params$W_out) + b_out
      u_r <- strenv$jnp$einsum("nm,mo->no", phi_r, params$W_out) + b_out
      logits <- u_l - u_r
      if (isTRUE(use_cross_term) && !is.null(params$M_cross)) {
        cross_term <- strenv$jnp$einsum("nm,mp,np->n", phi_l, params$M_cross, phi_r)
        cross_term <- strenv$jnp$reshape(cross_term, list(-1L, 1L))
        cross_out <- if (!is.null(params$W_cross_out)) {
          strenv$jnp$reshape(params$W_cross_out, list(1L, -1L))
        } else {
          strenv$jnp$zeros(list(1L, ai(params$W_out$shape[[2]])), dtype = strenv$dtj)
        }
        logits <- logits + cross_term * cross_out
      }
    }
    if (return_logits) {
      return(logits)
    }
    if (likelihood == "bernoulli") {
      return(strenv$jax$nn$sigmoid(strenv$jnp$squeeze(logits, axis = 1L)))
    }
    if (likelihood == "categorical") {
      return(strenv$jax$nn$softmax(logits, axis = -1L))
    }
    if (likelihood == "normal") {
      return(list(mu = strenv$jnp$squeeze(logits, axis = 1L),
                  sigma = if (!is.null(params$sigma)) params$sigma else strenv$jnp$array(1.)))
    }
  }

  TransformerPredict_single <- function(params, X_new, party_new,
                                        resp_party_new = NULL, resp_cov_new = NULL,
                                        return_logits = FALSE) {
    Xb <- strenv$jnp$array(to_index_matrix(X_new))$astype(strenv$jnp$int32)
    pb <- strenv$jnp$array(as.integer(party_new))$astype(strenv$jnp$int32)
    if (is.null(resp_party_new)) {
      resp_party_new <- rep(0L, nrow(X_new))
    }
    resp_p <- strenv$jnp$array(as.integer(resp_party_new))$astype(strenv$jnp$int32)
    if (is.null(resp_cov_new)) {
      resp_cov_new <- if (!is.null(resp_cov_mean)) {
        matrix(rep(resp_cov_mean, each = nrow(X_new)), nrow = nrow(X_new))
      } else {
        matrix(0, nrow = nrow(X_new), ncol = 0L)
      }
    }
    resp_c <- strenv$jnp$array(as.matrix(resp_cov_new))$astype(ddtype_)

    model_info_local <- list(
      model_dims = ModelDims,
      cand_party_to_resp_idx = cand_party_to_resp_idx_jnp
    )

    embed_candidate <- function(X_idx, party_idx, resp_p) {
      neural_build_candidate_tokens_hard(X_idx, party_idx,
                                         model_info = model_info_local,
                                         resp_party_idx = resp_p,
                                         params = params)
    }

    run_transformer <- function(tokens) {
      neural_run_transformer(tokens,
                             model_info = list(model_depth = ModelDepth,
                                               model_dims = ModelDims,
                                               n_heads = TransformerHeads,
                                               head_dim = head_dim),
                             params = params)
    }

    ctx_tokens <- neural_build_context_tokens_batch(model_info = model_info_local,
                                                    resp_party_idx = resp_p,
                                                    resp_cov = resp_c,
                                                    params = params)
    choice_tok <- strenv$jnp$reshape(params$E_choice, list(1L, 1L, ModelDims))
    choice_tok <- choice_tok * strenv$jnp$ones(list(Xb$shape[[1]], 1L, 1L))
    cand_tokens <- embed_candidate(Xb, pb, resp_p)
    token_parts <- list(choice_tok)
    if (!is.null(ctx_tokens)) {
      token_parts <- c(token_parts, list(ctx_tokens))
    }
    token_parts <- c(token_parts, list(cand_tokens))
    tokens <- strenv$jnp$concatenate(token_parts, axis = 1L)
    tokens <- run_transformer(tokens)
    choice_out <- strenv$jnp$take(tokens, strenv$jnp$arange(1L), axis = 1L)
    choice_out <- strenv$jnp$squeeze(choice_out, axis = 1L)
    b_out <- if (!is.null(params$b_out)) {
      params$b_out
    } else {
      strenv$jnp$zeros(list(ai(params$W_out$shape[[2]])), dtype = strenv$dtj)
    }
    logits <- strenv$jnp$einsum("nm,mo->no", choice_out, params$W_out) + b_out

    if (return_logits) {
      return(logits)
    }
    if (likelihood == "bernoulli") {
      return(strenv$jax$nn$sigmoid(strenv$jnp$squeeze(logits, axis = 1L)))
    }
    if (likelihood == "categorical") {
      return(strenv$jax$nn$softmax(logits, axis = -1L))
    }
    if (likelihood == "normal") {
      return(list(mu = strenv$jnp$squeeze(logits, axis = 1L),
                  sigma = if (!is.null(params$sigma)) params$sigma else strenv$jnp$array(1.)))
    }
  }

  coerce_party_idx <- function(party_vec, n_rows) {
    if (is.null(party_vec)) {
      return(rep(0L, n_rows))
    }
    if (is.numeric(party_vec)) {
      idx <- as.integer(party_vec)
      if (any(idx >= n_party_levels)) {
        idx <- idx - 1L
      }
    } else {
      idx <- match(as.character(party_vec), party_levels) - 1L
    }
    idx[is.na(idx)] <- 0L
    idx
  }
  coerce_resp_party_idx <- function(party_vec, n_rows) {
    if (is.null(party_vec)) {
      return(rep(0L, n_rows))
    }
    if (is.numeric(party_vec)) {
      idx <- as.integer(party_vec)
      if (any(idx >= n_resp_party_levels)) {
        idx <- idx - 1L
      }
    } else {
      idx <- match(as.character(party_vec), resp_party_levels) - 1L
    }
    idx[is.na(idx)] <- 0L
    idx
  }

  to_r_array <- function(x) {
    if (is.null(x) || is.numeric(x)) {
      return(x)
    }
    tryCatch(reticulate::py_to_r(strenv$np$array(x)),
             error = function(e) {
               tryCatch(reticulate::py_to_r(x), error = function(e2) x)
             })
  }

  coerce_prediction_output <- function(pred) {
    if (likelihood == "bernoulli") {
      return(as.numeric(to_r_array(pred)))
    }
    if (likelihood == "categorical") {
      return(as.matrix(to_r_array(pred)))
    }
    if (likelihood == "normal") {
      return(list(
        mu = as.numeric(to_r_array(pred$mu)),
        sigma = as.numeric(to_r_array(pred$sigma))
      ))
    }
    pred
  }

  my_model <- function(...) {
    args <- list(...)
    if (pairwise_mode) {
      X_left_new <- args$X_left_new
      X_right_new <- args$X_right_new
      party_left_new <- args$party_left_new
      party_right_new <- args$party_right_new
      resp_party_new <- args$resp_party_new
      resp_cov_new <- args$resp_cov_new

      if (is.null(X_left_new) || is.null(X_right_new)) {
        if (length(args) < 2L) {
          stop("pairwise my_model requires X_left_new and X_right_new.", call. = FALSE)
        }
        if (is.null(X_left_new)) X_left_new <- args[[1]]
        if (is.null(X_right_new)) X_right_new <- args[[2]]
        if (length(args) >= 3L && is.null(party_left_new)) party_left_new <- args[[3]]
        if (length(args) >= 4L && is.null(party_right_new)) party_right_new <- args[[4]]
        if (length(args) >= 5L && is.null(resp_party_new)) resp_party_new <- args[[5]]
        if (length(args) >= 6L && is.null(resp_cov_new)) resp_cov_new <- args[[6]]
      }

      party_left_new <- coerce_party_idx(party_left_new, nrow(X_left_new))
      party_right_new <- coerce_party_idx(party_right_new, nrow(X_right_new))
      resp_party_new <- coerce_resp_party_idx(resp_party_new, nrow(X_left_new))
      pred <- TransformerPredict_pair(ParamsMean, X_left_new, X_right_new,
                                      party_left_new, party_right_new,
                                      resp_party_new, resp_cov_new)
      return(coerce_prediction_output(pred))
    }

    X_new <- args$X_new
    party_new <- args$party_new
    resp_party_new <- args$resp_party_new
    resp_cov_new <- args$resp_cov_new

    if (is.null(X_new)) {
      if (!is.null(args$X_left_new)) {
        X_new <- args$X_left_new
        if (is.null(party_new) && !is.null(args$party_left_new)) {
          party_new <- args$party_left_new
        }
      } else if (length(args) >= 1L) {
        X_new <- args[[1]]
        if (length(args) >= 2L && is.null(party_new)) party_new <- args[[2]]
        if (length(args) >= 3L && is.null(resp_party_new)) resp_party_new <- args[[3]]
        if (length(args) >= 4L && is.null(resp_cov_new)) resp_cov_new <- args[[4]]
      }
    }

    if (is.null(X_new)) {
      stop("my_model requires X_new for single-candidate predictions.", call. = FALSE)
    }
    party_new <- coerce_party_idx(party_new, nrow(X_new))
    resp_party_new <- coerce_resp_party_idx(resp_party_new, nrow(X_new))
    pred <- TransformerPredict_single(ParamsMean, X_new, party_new,
                                      resp_party_new, resp_cov_new)
    coerce_prediction_output(pred)
  }

  # Neural parameter vector and diagonal posterior covariance
  param_schema <- neural_build_param_schema(
    params = ParamsMean,
    n_factors = length(factor_levels),
    model_depth = ModelDepth
  )
  param_names <- param_schema$param_names
  param_shapes <- param_schema$param_shapes
  param_sizes <- param_schema$param_sizes
  param_offsets <- param_schema$param_offsets
  param_total <- as.integer(param_schema$n_params)

  theta_mean <- neural_flatten_params(ParamsMean, param_schema, dtype = ddtype_)
  theta_mean_num <- as.numeric(strenv$np$array(theta_mean))

  var_parts <- lapply(seq_along(param_names), function(i_) {
    name <- param_names[[i_]]
    draws <- get_param_draws(name)
    if (is.null(draws)) {
      return(strenv$jnp$zeros(list(ai(param_sizes[[i_]])), dtype = ddtype_))
    }
    strenv$jnp$ravel(strenv$jnp$var(draws, 0L:1L))
  })
  param_var_vec <- if (length(var_parts) == 0L) {
    strenv$jnp$array(numeric(0), dtype = ddtype_)
  } else {
    strenv$jnp$concatenate(var_parts, axis = 0L)
  }
  param_var <- as.numeric(strenv$np$array(param_var_vec))
  if (length(param_var) < param_total) {
    param_var <- c(param_var, rep(0, param_total - length(param_var)))
  }
  if (length(param_var) > param_total) {
    param_var <- param_var[seq_len(param_total)]
  }
  if (uncertainty_scope == "output") {
    keep <- param_names %in% c("W_out", "b_out", "sigma", "W_cross_out")
    mask <- unlist(mapply(function(keep_i, size_i) rep(keep_i, size_i),
                          keep, param_sizes))
    if (length(mask) == length(param_var)) {
      param_var <- param_var * as.numeric(mask)
    }
  }
  vcov_OutcomeModel <- c(0, param_var)
  vcov_OutcomeModel_by_k <- NULL

  EST_INTERCEPT_tf <- strenv$jnp$array(matrix(0, nrow = 1L, ncol = 1L), dtype = strenv$dtj)
  EST_COEFFICIENTS_tf <- strenv$jnp$reshape(theta_mean, list(-1L, 1L))
  my_mean <- numeric(0)
  my_mean_full <- NULL
  if (exists("K", inherits = TRUE) && is.numeric(K) && K > 1) {
    base_vec <- c(0, theta_mean_num)
    my_mean_full <- matrix(rep(base_vec, K), ncol = K)
    vcov_OutcomeModel_by_k <- replicate(K, vcov_OutcomeModel, simplify = FALSE)
  }

  resp_cov_mean_jnp <- if (!is.null(resp_cov_mean)) {
    strenv$jnp$array(as.numeric(resp_cov_mean))$astype(ddtype_)
  } else {
    NULL
  }
  party_index_map <- NULL
  if (exists("GroupsPool", inherits = TRUE) && length(GroupsPool) > 0) {
    party_index_map <- setNames(vapply(GroupsPool, function(grp) {
      idx <- match(as.character(grp), party_levels) - 1L
      if (is.na(idx)) 0L else idx
    }, integer(1)), GroupsPool)
  }
  resp_party_index_map <- NULL
  if (exists("GroupsPool", inherits = TRUE) && length(GroupsPool) > 0) {
    resp_party_index_map <- setNames(vapply(GroupsPool, function(grp) {
      idx <- match(as.character(grp), resp_party_levels) - 1L
      if (is.na(idx)) 0L else idx
    }, integer(1)), GroupsPool)
  }

  fit_metrics <- NULL
  if (isTRUE(eval_control$enabled)) {
    n_total <- length(Y_use)
    if (n_total > 0L) {
      eval_idx <- seq_len(n_total)
      if (!is.null(eval_control$max_n) &&
          is.finite(eval_control$max_n) &&
          eval_control$max_n > 0L &&
          eval_control$max_n < n_total) {
        eval_seed <- eval_control$seed
        if (is.null(eval_seed) || is.na(eval_seed)) {
          eval_seed <- 123L
        }
        rng <- strenv$np$random$default_rng(as.integer(eval_seed))
        idx_py <- rng$choice(as.integer(n_total),
                             size = as.integer(eval_control$max_n),
                             replace = FALSE)
        eval_idx <- as.integer(reticulate::py_to_r(idx_py)) + 1L
      }

      to_numeric <- function(x) {
        as.numeric(strenv$np$array(x))
      }
      compute_auc <- function(y_true, y_score) {
        y_true <- as.numeric(y_true)
        y_score <- as.numeric(y_score)
        ok <- is.finite(y_true) & is.finite(y_score)
        y_true <- y_true[ok]
        y_score <- y_score[ok]
        if (!length(y_true)) return(NA_real_)
        pos <- y_true == 1
        neg <- y_true == 0
        n_pos <- sum(pos)
        n_neg <- sum(neg)
        if (n_pos == 0L || n_neg == 0L) return(NA_real_)
        ranks <- rank(y_score, ties.method = "average")
        (sum(ranks[pos]) - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)
      }
      compute_log_loss <- function(y_true, y_score, eps = 1e-12) {
        y_true <- as.numeric(y_true)
        y_score <- as.numeric(y_score)
        ok <- is.finite(y_true) & is.finite(y_score)
        y_true <- y_true[ok]
        y_score <- y_score[ok]
        if (!length(y_true)) return(NA_real_)
        p <- pmin(pmax(y_score, eps), 1 - eps)
        -mean(y_true * log(p) + (1 - y_true) * log(1 - p))
      }
      compute_multiclass_log_loss <- function(y_true, prob_mat, eps = 1e-12) {
        if (is.null(dim(prob_mat))) {
          prob_mat <- matrix(prob_mat, nrow = length(y_true), byrow = TRUE)
        }
        n_eval <- nrow(prob_mat)
        if (length(y_true) != n_eval) return(NA_real_)
        ok <- !is.na(y_true)
        y_true <- y_true[ok]
        prob_mat <- prob_mat[ok, , drop = FALSE]
        if (!length(y_true)) return(NA_real_)
        idx <- cbind(seq_along(y_true), y_true + 1L)
        p <- prob_mat[idx]
        p <- pmin(pmax(p, eps), 1 - eps)
        -mean(log(p))
      }
      format_metric <- function(label, value, digits = 4) {
        if (is.null(value) || !is.finite(value)) return(NULL)
        fmt <- paste0("%s=%.", digits, "f")
        sprintf(fmt, label, value)
      }

      if (pairwise_mode) {
        X_left_eval <- X_left[eval_idx, , drop = FALSE]
        X_right_eval <- X_right[eval_idx, , drop = FALSE]
        party_left_eval <- party_left[eval_idx]
        party_right_eval <- party_right[eval_idx]
        resp_party_eval <- resp_party_use[eval_idx]
        resp_cov_eval <- if (!is.null(X_use) && n_resp_covariates > 0L) {
          X_use[eval_idx, , drop = FALSE]
        } else {
          NULL
        }
        pred <- TransformerPredict_pair(ParamsMean, X_left_eval, X_right_eval,
                                        party_left_eval, party_right_eval,
                                        resp_party_eval, resp_cov_eval)
      } else {
        X_eval <- X_single[eval_idx, , drop = FALSE]
        party_eval <- party_single[eval_idx]
        resp_party_eval <- resp_party_use[eval_idx]
        resp_cov_eval <- if (!is.null(X_use) && n_resp_covariates > 0L) {
          X_use[eval_idx, , drop = FALSE]
        } else {
          NULL
        }
        pred <- TransformerPredict_single(ParamsMean, X_eval, party_eval,
                                          resp_party_eval, resp_cov_eval)
      }

      y_eval <- Y_use[eval_idx]
      n_eval <- length(y_eval)
      subset_note <- if (n_eval < n_total) {
        sprintf("n=%d/%d", n_eval, n_total)
      } else {
        sprintf("n=%d", n_eval)
      }

      if (likelihood == "bernoulli") {
        y_eval <- as.numeric(y_eval)
        keep <- is.finite(y_eval) & (y_eval %in% c(0, 1))
        y_eval <- y_eval[keep]
        prob <- to_numeric(pred)
        prob <- prob[keep]
        auc <- compute_auc(y_eval, prob)
        log_loss <- compute_log_loss(y_eval, prob)
        accuracy <- if (length(y_eval)) mean((prob >= 0.5) == y_eval) else NA_real_
        brier <- if (length(y_eval)) mean((prob - y_eval) ^ 2) else NA_real_
        fit_metrics <- list(
          likelihood = likelihood,
          n_eval = length(y_eval),
          auc = auc,
          log_loss = log_loss,
          accuracy = accuracy,
          brier = brier,
          eval_note = subset_note
        )
        metric_items <- Filter(Negate(is.null), list(
          format_metric("AUC", auc, 4),
          format_metric("LogLoss", log_loss, 4),
          format_metric("Acc", accuracy, 3),
          format_metric("Brier", brier, 4)
        ))
      } else if (likelihood == "categorical") {
        y_eval <- as.integer(as.factor(y_eval)) - 1L
        prob_mat <- reticulate::py_to_r(strenv$np$array(pred))
        prob_mat <- as.matrix(prob_mat)
        keep <- !is.na(y_eval)
        y_eval <- y_eval[keep]
        prob_mat <- prob_mat[keep, , drop = FALSE]
        if (length(y_eval)) {
          log_loss <- compute_multiclass_log_loss(y_eval, prob_mat)
          pred_class <- max.col(prob_mat) - 1L
          accuracy <- mean(pred_class == y_eval, na.rm = TRUE)
        } else {
          log_loss <- NA_real_
          accuracy <- NA_real_
        }
        fit_metrics <- list(
          likelihood = likelihood,
          n_eval = length(y_eval),
          log_loss = log_loss,
          accuracy = accuracy,
          eval_note = subset_note
        )
        metric_items <- Filter(Negate(is.null), list(
          format_metric("LogLoss", log_loss, 4),
          format_metric("Acc", accuracy, 3)
        ))
      } else {
        y_eval <- as.numeric(y_eval)
        keep <- is.finite(y_eval)
        y_eval <- y_eval[keep]
        mu <- to_numeric(pred$mu)
        mu <- mu[keep]
        sigma <- to_numeric(pred$sigma)
        if (length(sigma) == 1L && length(y_eval) > 1L) {
          sigma <- rep(sigma, length(y_eval))
        } else {
          sigma <- sigma[keep]
        }
        rmse <- if (length(y_eval)) sqrt(mean((mu - y_eval) ^ 2)) else NA_real_
        mae <- if (length(y_eval)) mean(abs(mu - y_eval)) else NA_real_
        nll <- NA_real_
        if (length(y_eval) && length(sigma) == length(y_eval) && all(is.finite(sigma)) &&
            all(sigma > 0)) {
          nll <- mean(0.5 * log(2 * pi * sigma ^ 2) + (y_eval - mu) ^ 2 / (2 * sigma ^ 2))
        }
        fit_metrics <- list(
          likelihood = likelihood,
          n_eval = length(y_eval),
          rmse = rmse,
          mae = mae,
          nll = nll,
          eval_note = subset_note
        )
        metric_items <- Filter(Negate(is.null), list(
          format_metric("RMSE", rmse, 4),
          format_metric("MAE", mae, 4),
          format_metric("NLL", nll, 4)
        ))
      }

      if (!is.null(fit_metrics) && length(metric_items) > 0L) {
        message(sprintf("Neural fit metrics (%s, %s): %s",
                        ifelse(pairwise_mode, "pairwise", "single"),
                        subset_note,
                        paste(metric_items, collapse = ", ")))
      }
    }
  }

  if (!is.null(svi_loss_curve) && length(svi_loss_curve) > 0L) {
    finite_losses <- svi_loss_curve[is.finite(svi_loss_curve)]
    svi_summary <- list(
      svi_elbo = svi_loss_curve,
      svi_elbo_final = if (length(finite_losses)) tail(finite_losses, 1) else NA_real_
    )
    if (is.null(fit_metrics)) {
      fit_metrics <- svi_summary
    } else {
      fit_metrics <- c(fit_metrics, svi_summary)
    }
  }

  neural_model_info <- list(
    params = ParamsMean,
    param_names = param_names,
    param_shapes = param_shapes,
    param_sizes = param_sizes,
    param_offsets = param_offsets,
    n_params = ai(param_total),
    uncertainty_scope = uncertainty_scope,
    factor_levels = factor_levels,
    factor_index_list = factor_index_list,
    implicit = isTRUE(holdout_indicator == 1L),
    pairwise_mode = pairwise_mode,
    n_factors = ai(length(factor_levels)),
    n_candidate_tokens = n_candidate_tokens,
    party_levels = party_levels,
    n_party_levels = ai(n_party_levels),
    n_matchup_levels = ai(n_matchup_levels),
    resp_party_levels = resp_party_levels,
    party_index_map = party_index_map,
    resp_party_index_map = resp_party_index_map,
    cand_party_to_resp_idx = cand_party_to_resp_idx_jnp,
    resp_cov_mean = resp_cov_mean_jnp,
    n_resp_covariates = n_resp_covariates,
    has_stage_token = !is.null(ParamsMean$E_stage),
    has_matchup_token = !is.null(ParamsMean$E_matchup),
    has_resp_party_token = !is.null(ParamsMean$E_resp_party),
    has_rel_token = !is.null(ParamsMean$E_rel),
    has_feature_id_embedding = !is.null(ParamsMean$E_feature_id),
    has_segment_embedding = !is.null(ParamsMean$E_segment),
    has_sep_token = !is.null(ParamsMean$E_sep),
    has_stage_head = !is.null(ParamsMean$W_stage),
    has_ctx_head = !is.null(ParamsMean$W_ctx),
    has_choice_token = !is.null(ParamsMean$E_choice),
    cross_candidate_encoder = isTRUE(use_cross_term),
    cross_candidate_encoder_mode = cross_candidate_encoder_mode,
    has_cross_encoder = isTRUE(use_cross_encoder),
    has_cross_term = !is.null(ParamsMean$M_cross),
    choice_token_index = 0L,
    likelihood = likelihood,
    fit_metrics = fit_metrics,
    svi_loss_curve = svi_loss_curve,
    stage_diagnostics = stage_diagnostics,
    model_dims = ModelDims,
    model_depth = ModelDepth,
    n_heads = TransformerHeads,
    head_dim = head_dim
  )

  message(sprintf("Bayesian Transformer complete. Pairwise=%s, Heads=%d, Depth=%d, Hidden=%d; likelihood=%s.",
                  pairwise_mode, TransformerHeads, ModelDepth, MD_int, likelihood))
}
