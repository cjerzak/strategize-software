# This file is part of the testthat infrastructure for the strategize package.
# It is automatically executed by R CMD check.

library(testthat)
library(strategize)

test_check("strategize")
